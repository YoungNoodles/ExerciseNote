package com.cetc;

import java.util.Scanner;

public class GirlTest {
    private static final Scanner SC = new Scanner(System.in);

    public static void main(String[] args) {
        Girl g = new Girl();

        while (true) {
            try {
                System.out.println("请输入女孩的姓名");
                //输入姓名字符串
                String name = SC.nextLine();
                //给对象name变量赋值
                g.setName(name);

                System.out.println("请输入女孩的年龄");
                //输入年龄字符串
                String ageStr = SC.nextLine();
                //将年龄字符串转换成数字
                int age = Integer.parseInt(ageStr);
                //给对象age变量赋值
                g.setAge(age);

                break;
            } catch (NameFormatException e) {
                e.printStackTrace();
            } catch (NumberFormatException e) {
                e.printStackTrace();
            } catch (AgeFormatException e) {
                e.printStackTrace();
            }
        }

        System.out.println(g);
    }
}
