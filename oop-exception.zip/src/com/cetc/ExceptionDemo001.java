package com.cetc;

public class ExceptionDemo001 {
    public static void main(String[] args) {
        int[] arr = {1,2,3,4,5,6,7};

//        System.out.println(arr[10]);
//        System.out.println("看看我执行了吗");

        //异常处理
        try{
            System.out.println(arr[10]);
        }catch(ArrayIndexOutOfBoundsException e){
            System.out.println("异常了，出错了");
        }

        try{
            System.out.println(arr[0]);
        }catch(RuntimeException e){
            System.out.println("我运行了没");
        }

        System.out.println("该结束了");
    }
}
