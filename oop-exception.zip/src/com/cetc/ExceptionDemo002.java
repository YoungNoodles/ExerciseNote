package com.cetc;

public class ExceptionDemo002 {
    public static void main(String[] args) {
        int[] arr = {};
        int max;

        try {
            max = getMax(arr);
            System.out.println(max);
        } catch (NullPointerException | ArrayIndexOutOfBoundsException e) {
            e.printStackTrace();
        }
        System.out.println("看看我运行了吗");
    }

    public static int getMax(int[] arr){
        if(arr == null){//判断arr是否为null，若为null则抛出空指针异常
            throw new NullPointerException();
        }

        if(arr.length == 0){//判断arr是否为空数组，若为空则抛出索引越界异常异常
            throw new ArrayIndexOutOfBoundsException();
        }

        int max = arr[0];
        for (int i : arr) {
            if(i > max){
                max = i;
            }
        }

        return max;
    }
}
