import com.CETC.ui.GameJFrame;
import com.CETC.ui.LoginJFrame;
import com.CETC.ui.RegisterJFrame;

public class APP {
    public static void main(String[] args) {

//        new LoginJFrame();

        new GameJFrame();

//        new RegisterJFrame();
    }
}