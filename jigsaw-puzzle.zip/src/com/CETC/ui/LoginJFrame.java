package com.CETC.ui;

import javax.swing.*;

/**
 * 登录界面类
 * 与游戏登录有关的逻辑写在登录类中
 * <p>
 * 若选择注册选项，则关闭登录界面【LoginJFrame】，打开注册界面【RegisterJFrame】
 * <p>
 * 获取用户名
 * 获取密码
 * <输入密码时，加密显示密码，长按显示按钮显示原码>
 * 获取验证码
 * 比较用户名和密码，若有误则返回【用户名或密码错误】
 * 比较验证码，若有误则返回【验证码错误】
 * 全部正确则隐藏登录界面【LoginJFrame】，打开游戏主界面【GameJFrame】
 */
public class LoginJFrame extends JFrame {
    public LoginJFrame() {
        //设置登录界面宽高
        this.setSize(480, 500);
        //设置登录界面窗口标题
        this.setTitle("拼图单机版 v.0.1 -- 登录");
        //设置窗口居中
        this.setLocationRelativeTo(null);
        //设置默认关闭模式
        this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        //显示登录界面
        this.setVisible(true);
    }

}
