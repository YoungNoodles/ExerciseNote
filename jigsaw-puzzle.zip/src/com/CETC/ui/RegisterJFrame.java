package com.CETC.ui;

import javax.swing.*;

/**
 * 注册界面类
 * 与注册有关的逻辑写在注册类中
 * <p>
 * 若选择【返回】按钮，关闭注册界面【RegisterJFrame】，打开登录界面【LoginJFrame】
 * <p>
 * 若选择【重置】按钮，清空输入的用户名、密码、重复输入的密码
 * <p>
 * 点击【注册】按钮
 * 获取用户名
 * 获取密码
 * 获取重复确认的密码
 * 判断用户名唯一性
 * 若用户名已存在，重新输入用户名
 * 判断两次密码一致性
 * 若密码不一致，重新输入密码
 * 注册成功后，弹出【注册成功】界面，关闭注册界面【RegisterJFrame】，显示登录界面【LoginJFrame】
 */
public class RegisterJFrame extends JFrame {
    public RegisterJFrame() {
        //设置注册界面宽高
        this.setSize(480, 500);
        //设置注册界面窗口标题
        this.setTitle("拼图单机版 v.0.1 -- 注册");
        //设置窗口居中
        this.setLocationRelativeTo(null);
        //设置默认关闭模式
        this.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        //显示注册界面
        this.setVisible(true);
    }
}
