package com.CETC.ui;

import javax.swing.*;
import javax.swing.border.BevelBorder;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.Random;

/**
 * 游戏操作主界面类
 * 与游戏过程有关的逻辑写在游戏类中
 * 游戏操作
 * 切换图片
 * 重新开始：重新打乱图片顺序
 * 退出登录：关闭游戏主界面【GameJFrame】，显示登录界面【LoginJFrame】
 */
public class GameJFrame extends JFrame implements KeyListener {

    private final int[] BASIC = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 0};
    /**
     * 定义一个二维数组记录图片的顺序
     */
    private final int[][] RANDOM = new int[4][4];

    /**
     * 定义整型变量，记录空白格的行索引
     */
    private int x;

    /**
     * 定义整型变量，记录空白格的列索引
     */
    private int y;
    private boolean type;

    public GameJFrame() {
        //初始化窗口
        initGameJFrame();
        //初始化菜单
        initGameJMenuBar();
        //写个按钮
        //initButton();
        //初始化数据（打乱图片）
        initDate();
        //拼图图片界面
        initImage();


        //显示游戏主界面【一定要在设置完之后再显示】
        this.setVisible(true);
    }

    /**
     * 初始化窗口
     */
    private void initGameJFrame() {
        //设置游戏主界面宽高
        this.setSize(608, 680);
        //设置游戏主界面窗口标题
        this.setTitle("拼图单机版 v.0.1");
        //设置窗口居中
        this.setLocationRelativeTo(null);
        //设置关闭模式
        this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        //取消默认居中放置，取消了才能按照自定义设置显示组件位置
        this.setLayout(null);
        //给界面添加键盘监听事件
        this.addKeyListener(this);
    }

    /**
     * 初始化菜单栏
     */
    private void initGameJMenuBar() {
        //创建菜单栏JMenuBar
        JMenuBar gameJMenuBar = new JMenuBar();
        //创建选项栏【选项】【关于黑马】
        JMenu functionJMenu = new JMenu("选项");
        JMenu aboutJMenu = new JMenu("关于黑马");
        //创建项栏中的条目【更换图片】【重新游戏】【退出登录】【关闭游戏】  【公众号】
        JMenuItem rePlaceItem = new JMenuItem("更换图片");
        JMenuItem rePlayItem = new JMenuItem("重新游戏");
        JMenuItem reLoginItem = new JMenuItem("退出登录");
        JMenuItem closeItem = new JMenuItem("关闭游戏");

        JMenuItem accountItem = new JMenuItem("关注黑马公众号");
        //将条目添加到选项中
        functionJMenu.add(rePlaceItem);
        functionJMenu.add(rePlayItem);
        functionJMenu.add(reLoginItem);
        functionJMenu.add(closeItem);

        aboutJMenu.add(accountItem);
        //将选项添加到菜单栏中
        gameJMenuBar.add(functionJMenu);

        gameJMenuBar.add(aboutJMenu);
        //将菜单栏添加到窗口中
        this.setJMenuBar(gameJMenuBar);
    }

    /*private void initButton() {
        //创建一个按钮【JButton】对象
        JButton jButton = new JButton("重新打乱");
        //给按钮设置位置和大小
        jButton.setBounds(1, 450, 100, 45);
        //给按钮添加监听\\现在添加的是动作监听
        jButton.addActionListener(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("我运行了吗");
            }
        });
        //将JButton对象添加到界面中
        this.getContentPane().add(jButton);
    }*/

    /**
     * 打乱添加图片时的索引顺序
     */
    private void initDate() {
        Random ra = new Random();
        int[] arr = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 0};
        //打乱顺序排放
        for (int i = 0; i < arr.length; i++) {
            //获取一个随机数作为索引
            int index = ra.nextInt(16);
            //判断，将该索引指向的数字添加到数组中
            if (arr[index] < 16) {
                RANDOM[i / 4][i % 4] = arr[index];
                //获取空白格所在位置的索引
                //开局记录初始化空白格位置
                if (arr[index] == 0) {
                    x = i / 4;
                    y = i % 4;
                }
                arr[index] = 16;
            } else {
                i--;
            }

        }

    }

    /**
     * 向界面中添加图片
     */
    private void initImage() {
        //先清空所有的图片
        this.getContentPane().removeAll();

        if (ifWin()) {
            System.out.println(ifWin());

            //输出胜利图片
            JLabel win = new JLabel(new ImageIcon("image\\win.png"));
            //设置输出位置
            win.setBounds(200, 200, 197, 73);
            this.getContentPane().add(win);
            //输出整体图片
            JLabel all = new JLabel(new ImageIcon("image\\animal\\animal7\\all.jpg"));
            //设置输出位置
            all.setBounds(83, 134, 420, 420);
            this.getContentPane().add(all);

        } else {
            System.out.println(ifWin());
            for (int i = 0; i < 4; i++) {

                for (int j = 0; j < 4; j++) {
                    //创建一个图片imageIcon对象
                    //创建一个容器对象JLabel
                    JLabel picture = new JLabel(new ImageIcon("image\\animal\\animal7\\" + RANDOM[i][j] + ".jpg"));
                    //指定图像位置
                    picture.setBounds(105 * j + 83, 105 * i + 134, 105, 105);
                    //给图片添加边框
                    picture.setBorder(new BevelBorder(BevelBorder.LOWERED));
                    //将JLabel添加到界面中
                    //this.add(picture);错哒
                    this.getContentPane().add(picture);
                }
            }

        }

        //初始化背景
        initBackGround();

        //重新加载图片
        this.getContentPane().repaint();
    }

    /**
     * 美化界面，给拼图加背景
     * 先添加的图片在上层，后添加的图片在底层
     */
    private void initBackGround() {
        //创建一个JImageIcon对象接收背景图片
        //创建一个JLabel容器管理背景图片
        JLabel backGround = new JLabel(new ImageIcon("image\\background.png"));
        //设置背景图位置
        backGround.setBounds(39, 39, 508, 560);
        //将背景图加入到隐藏容器
        this.getContentPane().add(backGround);
    }


    /**
     * 我是Typed我没用
     *
     * @param e the event to be processed
     */
    @Override
    public void keyTyped(KeyEvent e) {

    }

    @Override
    public void keyPressed(KeyEvent e) {
    }

    @Override
    public void keyReleased(KeyEvent e) {
        int keyCode = e.getKeyCode();
//        System.out.println(keyCode);
        if (keyCode == 37) {
            //按方向左键，空白格右移
            //先判断右侧是否为空
            if (y < 3) {
                //将空白格索引右侧索引的数据传给空白格索引，空白格列索引自增1，数据更新
                RANDOM[x][y] = RANDOM[x][++y];
                //将右侧索引的数据改为零
                RANDOM[x][y] = 0;
                //再输出图片
                initImage();
                //若胜利，则执行胜利方法
                /*if (ifWin()) {
                    finishGame();
                }*/
            }
        } else if (keyCode == 38) {
            //按方向上建，空白格下移
            if (x < 3) {
                //将空白格索引右侧索引的数据传给空白格索引，空白格行索引自增1，数据更新
                RANDOM[x][y] = RANDOM[++x][y];
                //将下方索引的数据改为零
                RANDOM[x][y] = 0;
                //再输出图片
                initImage();
                //若胜利，则执行胜利方法
                /*if (ifWin()) {
                    finishGame();
                }*/
            }
        } else if (keyCode == 39) {
            //按方向右键，空白格左移
            if (y > 0) {
                //将空白格索引右侧索引的数据传给空白格索引，空白格列索引自减1，数据更新
                RANDOM[x][y] = RANDOM[x][--y];
                //将左侧索引的数据改为零
                RANDOM[x][y] = 0;
                //再输出图片
                initImage();
                //若胜利，则执行胜利方法
                /*if (ifWin()) {
                    finishGame();
                }*/
            }
        } else if (keyCode == 40) {
            //按方向下键，空白格上移
            if (x > 0) {
                //将空白格索引右侧索引的数据传给空白格索引，空白格行索引自减1，数据更新
                RANDOM[x][y] = RANDOM[--x][y];
                //将上方索引的数据改为零
                RANDOM[x][y] = 0;
                //再输出图片
                initImage();
                //若胜利，则执行胜利方法
                /*if (ifWin()) {
                    finishGame();
                }*/
            }
        } else if (keyCode == 32) {
            //展示完整图片
            if (type) {
                initImage();
                type = !type;
            } else {
                showAll();
                type = !type;
            }

        } else if (keyCode == 65) {
            //按a/A直接胜利
            for (int i = 0; i < BASIC.length; i++) {
                RANDOM[i / 4][i % 4] = BASIC[i];
            }
            x = 3;
            y = 3;
            //再输出图片
            initImage();
            //若胜利，则执行胜利方法
            /*if (ifWin()) {
                finishGame();
            }*/


        }

    }

    /**
     * 展示完整图片
     */
    private void showAll() {
        //清空组件
        this.getContentPane().removeAll();
        //添加完整图片
        JLabel all = new JLabel(new ImageIcon("image\\animal\\animal7\\all.jpg"));
        //设置显示位置
        all.setBounds(83,134,420,420);
        this.getContentPane().add(all);
        //显示背景
        initBackGround();
        //重新打印图片
        this.getContentPane().repaint();
    }

    private void finishGame() {

        //清空所有组件
        getContentPane().removeAll();
        //输出胜利图片
        JLabel win = new JLabel(new ImageIcon("image\\win.png"));
        //设置输出位置
        win.setBounds(100, 200, 197, 73);
        getContentPane().add(win);
        //输出整体图片
        JLabel all = new JLabel(new ImageIcon("image\\animal\\animal7\\all.jpg"));
        //设置输出位置
        all.setBounds(83, 134, 420, 420);
        getContentPane().add(all);
        //输出背景图片
        initBackGround();
        //重新打印组件
        getContentPane().repaint();

    }

    /**
     * 判断游戏是否胜利，达成胜利条件返回true
     */
    private boolean ifWin() {
        for (int i = 0; i < BASIC.length; i++) {
            System.out.print(RANDOM[i / 4][i % 4] + " ");
            if (RANDOM[i / 4][i % 4] != BASIC[i]) {
                return false;
            }
        }
        return true;
    }
}
