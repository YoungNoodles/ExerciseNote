package com.CETC.test;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.Random;

public class MyJFrame extends JFrame implements KeyListener {

    //创建一个按钮对象
    //JButton jbt1 = new JButton("变大");
    //创建一个按钮对象
    //JButton jbt2 = new JButton("到处跑");

    public MyJFrame() {
        //新建JFrame对象，划定界面大小
        setSize(480, 720);
        //设置界面标题
        setTitle("按钮试验田");
        //设置界面关闭方式
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        //页面居中
        setLocationRelativeTo(null);
        //关闭默认摆放设置
        setLayout(null);

        //设置按钮大小，位置
        //jbt1.setSize(80,30);
        //jbt1.setLocation(0,0);
        //jbt2.setSize(80, 30);
        //Random ra = new Random();
        //jbt2.setLocation(ra.nextInt(390), ra.nextInt(670));

        //给按钮添加动作监听
        //jbt1.addActionListener(this);
        //jbt2.addActionListener(this);

        //将按钮加入到隐藏组件容器
        //getContentPane().add(jbt1);
        //this.getContentPane().add(jbt2);

        //给界面添加键盘监听
        this.addKeyListener(this);

        //显示界面
        this.setVisible(true);
    }

    /*@Override
    public void actionPerformed(ActionEvent e) {
        Object jbt = e.getSource();
        *//*if(jbt == jbt1){
            jbt1.setSize(100,100);
        }else *//*
        if (jbt == jbt2) {
            Random ra = new Random();
            jbt2.setLocation(ra.nextInt(390), ra.nextInt(680));
        }
    }*/

    @Override
    public void keyTyped(KeyEvent e) {
        //键入，一般不用
    }

    @Override
    public void keyPressed(KeyEvent e) {
        //按下触发
    }

    @Override
    public void keyReleased(KeyEvent e) {
        //松开触发
        int keyCode = e.getKeyCode();
        if (keyCode == 37) {
            System.out.println("按下左方向键");
        } else if (keyCode == 38) {
            System.out.println("按下上方向键");
        } else if (keyCode == 39) {
            System.out.println("按下右方向键");
        } else if (keyCode == 40) {
            System.out.println("按下下方向键");
        }
        System.out.println(keyCode);
    }
}
