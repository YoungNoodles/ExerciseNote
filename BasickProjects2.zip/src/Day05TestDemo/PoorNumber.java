package Day05TestDemo;

import java.util.Random;
import java.util.Scanner;

public class PoorNumber {
    public static void main(String[] args){
        Random ra = new Random();
        Scanner sc = new Scanner(System.in);
        int number = ra.nextInt(100)+1;
        while(true){
            System.out.print("Please scan in your answer:");
            int answer = sc.nextInt();
            if(answer == number){
                System.out.println("Bingo!");
                break;
            }else if(answer < number){
                System.out.println("That's small");
            }else{
                System.out.println("That's big");
            }
        }
    }
}
