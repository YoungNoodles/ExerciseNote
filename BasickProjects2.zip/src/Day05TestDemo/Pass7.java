package Day05TestDemo;

import java.util.Scanner;

public class Pass7 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        while (true) {
            System.out.print("请输入要开的数字：");
            int number = sc.nextInt();
            if(number == 0){break;}
            int i = 0;
            while (true) {
                if (number < 2) {
                    System.out.println("做不了！");
                    break;
                }else if(i * i > number){
                    break;
                }else{
                    i++;
                }
                //System.out.println(i + "\t" + s);
            }
            if (i * i > number) {
                System.out.println(i - 1);
            }else if(i * i == number && i * i > 1){
                System.out.println(i);
            }
        }
    }
}
