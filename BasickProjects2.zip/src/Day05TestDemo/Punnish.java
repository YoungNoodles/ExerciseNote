package Day05TestDemo;

import java.util.Random;
import java.util.Scanner;

public class Punnish {
    public static void main(String[] args){
        Random ra = new Random();
        Scanner sc = new Scanner(System.in);
        int i=1;
        while(true) {
            int number = ra.nextInt(100) + 1;
            System.out.print("Please scan in your answer:");
            int answer = sc.nextInt();
            while(i == 30){
                number = answer;
                break;
            }
            if(answer > 100){
                System.out.println("Your answer must in closed interval [1,100]!");
            }else if(answer == 0){
                break;
            }else if(answer == number){
                System.out.println("Bingo!");
                System.out.println(i);
                break;
            }else{
                System.out.println("Wrong!");
                i++;
            }
        }
    }
}
