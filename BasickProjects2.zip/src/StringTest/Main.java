package StringTest;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String strA = sc.nextLine();
        String strB = sc.nextLine();
        //严格比较

        System.out.println(EqualsTest.checkEqual(strA,strB));
        //有效字符比较

        System.out.println(ValidEqualsTest.checkValidEquals(strA,strB));
        //忽略大小写的比较

        System.out.println(IgnoreCaseEquals.checkICEquals(strA,strB));
    }
}
