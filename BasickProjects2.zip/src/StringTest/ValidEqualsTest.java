package StringTest;

public class ValidEqualsTest {
    private ValidEqualsTest(){}

    /**
     * 将空格去掉，只保留有效的字符，返回到私有属性str
     *
     * @param str
     * @return
     */
    private static /*String*/ String changeStr(String str) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < str.length(); i++) {
            if (str.charAt(i) != ' ') {
                sb.append(str.charAt(i));
            }
        }
        return sb.toString();
    }

    public static boolean checkValidEquals(String strA, String strB) {
        strA = changeStr(strA);
        strB = changeStr(strB);
        return EqualsTest.checkEqual(strA,strB);
    }
}
