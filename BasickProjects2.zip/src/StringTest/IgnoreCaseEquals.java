package StringTest;

public class IgnoreCaseEquals {
    private IgnoreCaseEquals(){}

    /**
     * 将大写变成小写，返回到对象的属性str
     *
     * @param //strA
     * @return
     */
    private static String changeStr(String str) {
        return str.toLowerCase();
    }

    public static boolean checkICEquals(String strA, String strB) {
        strA = changeStr(strA);
        strB = changeStr(strB);
        return EqualsTest.checkEqual(strA,strB);
    }
}
