package StringTest;

import java.util.Scanner;

public class EqualsTest {
    private EqualsTest(){}

    /**
     * 判断长度是否相等
     * @param strA
     * @param strB
     * @return
     */
    public static boolean checkLength(String strA, String strB) {
        //若两字符串长度相等则返回true
        return strA.length() == strB.length();
    }

    /**
     * 判断是否相等
     * @param strA
     * @param strB
     * @return
     */
    public static boolean checkEqual(String strA, String strB) {
        //先判断长度是否相等，若相等则继续进行后续比较，若不相等，则直接返回false
        if (checkLength(strA,strB)) {
            for (int i = 0; i < strA.length(); i++) {
                if (strA.charAt(i) != strB.charAt(i)) {
                    return false;
                }
            }
        } else {
            return false;
        }
        return true;
    }
}
