package Day08;

public class Phone {
    private String brand;
    private int prise;

    public Phone() {}

    public Phone(String brand, int prise) {
        this.brand = brand;
        this.prise = prise;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getBrand(){
        return brand;
    }

    public void setPrise(int n){
        if(n > 0 && n < 19999){
            prise = n;
        }else{
            System.out.println("太贵了你不对劲");
        }
    }

    public int getPrise(){
        return prise;
    }

    public void gaming(String brand) {
        System.out.println(brand + " is playing game");
    }

    public void calling() {
        System.out.println("calling with girlfriend");
    }
}
