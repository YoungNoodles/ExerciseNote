package Day08;

import com.sun.source.tree.Scope;

import java.util.Arrays;
import java.util.Scanner;

public class Method2D {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        /*//初始化二维数组，第一“[]”是列数，第二个“[]”是行数

        int[][] arr = new int[][]{{1, 2}, {3}, {5, 6}};
        for (int i = 0; i < arr.length; i++) {
            for (int j = 0; j < arr[i].length; j++) {
                System.out.print(arr[i][j] + " ");
            }
            if(i < arr.length - 1){System.out.println();}
        }*/

        /*
        //变量名甚至可以是中文，但是不要用

        int 你是谁 = 1;
        System.out.print(你是谁);*/

        /*
        //尝试手动输入二维数组

        int[][] arr = new int[3][3];
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                arr[i][j] = sc.nextInt();
//                System.out.print(arr[i][j]);
            }
        }
        for (int i = 0; i < arr.length; i++) {
            System.out.println(arr[i]);
        }

        for (int i = 0; i < arr[1].length; i++) {
            System.out.println(arr[1][i]);
        }*/

        /*//手动输入不等长的二维数组

        int length;
        int[][] arr = new int[3][];
        for (int i = 0; i < arr.length; i++) {
            length = sc.nextInt();
            arr[i] = new int[length];
            for (int j = 0; j < length; j++) {
                arr[i][j] = sc.nextInt();
            }
        }

        for (int i = 0; i < arr.length; i++) {
            for (int j = 0; j < arr[i].length; j++) {
                System.out.print(arr[i][j]+" ");
            }
            if(i < arr.length - 1){
                System.out.println();
            }
        }*/

        int[][] arr = new int[4][3];
        int sumSe = 0;
        int sumYe = 0;
        for (int i = 0; i < arr.length; i++) {
            for (int j = 0; j < arr[i].length; j++) {
                System.out.println("请输入第"+ (i * 3 + 1 + j) +"个月的营业额：");
                arr[i][j] = sc.nextInt();
                sumYe += arr[i][j];
                sumSe += arr[i][j];
            }
            System.out.println("第" + (i + 1) + "季度的营业额为：" + sumSe);
            sumSe = 0;
        }
        System.out.println("全年的营业额为：" + sumYe);
    }
}
