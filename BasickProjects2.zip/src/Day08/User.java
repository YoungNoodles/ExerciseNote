package Day08;

public class User {
    private String username;
    private String password;
    private long phonenumber;
    private String email;
    private String gender;
    private int age;


    public User(){}

    public User(String username, String password, long phonenumber, String email, String gender, int age){
        this.username = username;
        this.password = password;
        this.phonenumber = phonenumber;
        this.email = email;
        this.gender = gender;
        this.age = age;
    }

    public void setUserName(String username){
        this.username = username;
    }

    public void setPassword(String password){
        this.username = username;
    }

    public void setPhonenumber(long phonenumber){
        this.username = username;
    }

    public void setEmail(String email){
        this.username = username;
    }

    public void setGender(String gender){
        this.username = username;
    }

    public void setUserName(int age){
        this.username = username;
    }

    public String getUserName(){
        return username;
    }

    public String getPassWord(){
        return password;
    }

    public long getPhoneNumber(){
        return phonenumber;
    }

    public String getEmail(){
        return email;
    }

    public String getGender(){
        return gender;
    }

    public int getAge(){
        return age;
    }

    public void newRegister(){
        System.out.println("注册成功！");
    }
}
