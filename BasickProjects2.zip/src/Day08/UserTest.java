package Day08;

public class UserTest {
    public static void main(String[] args) {
//        User us = new User();
        User us = new User("Ysd","516078443",17366510259L,"dadda2000@163.com","男",22);
        System.out.println(us.getUserName());
        System.out.println(us.getPassWord());
        System.out.println(us.getPhoneNumber());
        System.out.println(us.getEmail());
        System.out.println(us.getGender());
        System.out.println(us.getAge());

        int length = us.getUserName().length();
        System.out.println(us +"\n"+ length);
            }
}
