package Day08;

public class PhoneTest {
    public static void main(String[] args) {
        Phone p = new Phone();
        p.setBrand("iPhone");
        System.out.println(p.getBrand());
        p.setPrise(10000);


        
    }
}
