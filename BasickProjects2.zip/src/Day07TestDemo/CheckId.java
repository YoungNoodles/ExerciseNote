package Day07TestDemo;

import java.util.Random;
import java.util.Scanner;

public class CheckId {
    public static void main(String[] args) {
        Random ra = new Random();
        Scanner sc = new Scanner(System.in);
        System.out.println("获取验证码请按'1'，退出请按'#'，再次提示请按'0'");
        while (true) {
            //char contral = sc.next().charAt(0);
            String contral = sc.next();
            if (contral.equals("#")) {
                System.out.print("已退出！");
                break;
            } else if (contral.equals("1")) {
                //生成前四位字母
                String bit = getLetters(ra);
                //生成最后一位数字位
                int last = ra.nextInt(10);
                bit = bit + last;
                //输出最终的验证码
                    System.out.println(bit);
                //System.out.println(last);
            } else if (contral.equals("0")) {
                System.out.println("获取验证码请按'1'，退出请按'#'，再次提示请按'0'");
            } else {
                System.out.println("错误指令请重新输入！");
            }
        }

        /*Random ra = new Random();
        char[] checkid = new char[4];
        char[] letter = {'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z','a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'};
        int last =ra.nextInt(10);
        for(int i = 0; i < 4; i++){
                int four = ra.nextInt(52);
                checkid[i] = letter[four];
            }
        for (int i = 0; i < 4; i++) {
            System.out.print(checkid[i]);
        }
        System.out.println(last);*/


    }

    private static String getLetters(Random ra) {
        //生成前四位字母
        String bit = "";
        for (int i = 0; i < 4; i++) {
            char number_1 = (char) (ra.nextInt(26) + 65);
            char number_2 = (char) (ra.nextInt(26) + 97);
            int choose = ra.nextInt(2);
            if (choose == 0) {
                bit = bit + number_1;
            } else {
                bit = bit + number_2;
            }
        }
        return bit;
    }
}
