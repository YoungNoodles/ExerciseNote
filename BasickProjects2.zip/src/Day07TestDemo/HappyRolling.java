package Day07TestDemo;

import java.util.Random;
import java.util.Scanner;

public class HappyRolling {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Random ra = new Random();

        //红球中奖数量和篮球是否中奖的标志
        int red = 0;
        int blue = 1;

        //红球的奖号和蓝球的奖号
        int[] redNum = redNum(sc);

        int blueNum = blueNum(sc);

        //判断红球中奖的数量
        red = redResult(redNum);
        //System.out.println(red);

        //判断蓝球是否中奖
        blue = blueResult(blueNum);
        //System.out.println(red);

        //判断获奖的等级并输出
        finalResult(red, blue);

    }

    private static int blueNum(Scanner sc) {
        //选择蓝球的奖号
        int blueNum;
        System.out.print("请选择蓝球号码：");
        while (true) {
            int blue = sc.nextInt();
            blueNum = blue;
            if (blueNum > 16 || blueNum < 0) {
                System.out.print("号码无效！请重新选择：");
            } else {
                break;
            }
        }
        return blueNum;
    }

    private static int[] redNum(Scanner sc) {
        //选择红球的奖号
        int[] redNum = new int[6];
        for (int i = 0; i < redNum.length; i++) {
            System.out.print("请选择第" + (i + 1) + "个红球号码：");
            while (true) {
                redNum[i] = sc.nextInt();
                if (redNum[i] > 33 || redNum[i] < 0) {
                    System.out.print("号码无效！请重新选择：");
                } else {
                    break;
                }
            }
        }
        return redNum;
    }

    public static int redResult(int[] redNum) {
        //判断红球的中奖个数
        Random ra = new Random();

        int red = 0;
        for (int i = 0; i < 6; i++) {
            int result = ra.nextInt(33) + 1;
            //System.out.println("第"+(i + 1)+"个中奖红球号码是："+result);
            if (redNum[i] == result) {
                red += 1;
            }
            //System.out.println(red);
        }
        return red;
    }

    public static int blueResult(int blueNum) {
        //判断蓝球是否中奖
        Random ra = new Random();

        int blue = 1;
        int result = ra.nextInt(16) + 1;
        //System.out.println("中奖蓝球号码是："+result);
        if (blueNum != result) {
            blue = 0;
        }
        //System.out.println(blue);
        return blue;
    }

    public static void finalResult(int red, int blue) {
        if (red == 0 && blue == 0){
            System.out.print("很遗憾，您未中奖");
        } else if(red == 0 && blue == 1) {
            System.out.print("恭喜中奖！\n六等奖：奖金5元");
        } else if (red == 1 && blue == 1) {
            System.out.print("恭喜中奖！\n六等奖：奖金5元");
        } else if (red == 2 && blue == 1) {
            System.out.print("恭喜中奖！\n六等奖：奖金5元");
        } else if (red == 3 && blue == 1) {
            System.out.print("恭喜中奖！\n五等奖：奖金10元");
        } else if (red == 4 && blue == 0) {
            System.out.print("恭喜中奖！\n五等奖：奖金10元");
        } else if (red == 4 && blue == 1) {
            System.out.print("恭喜中奖！\n四等奖：奖金200元");
        } else if (red == 5 && blue == 0) {
            System.out.print("恭喜中奖！\n四等奖：奖金200元");
        } else if (red == 5 && blue == 1) {
            System.out.print("恭喜中奖！\n三等奖：奖金3000元");
        } else if (red == 6 && blue == 0) {
            System.out.print("恭喜中奖！\n二等奖：奖金500万元");
        } else {
            System.out.print("恭喜中奖！\n一等奖：奖金1000万元");
        }
    }


}
