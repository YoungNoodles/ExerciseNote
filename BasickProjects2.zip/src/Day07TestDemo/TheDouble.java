package Day07TestDemo;

import java.util.Random;
import java.util.Scanner;

public class TheDouble {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int[] resultRed = new int[33];
        for (int re = 0; re < resultRed.length; re++) {
            resultRed[re] = re;
        }

        //确定中奖号码
        int[] priseNumber = priseNumber(resultRed);
        /*for (int i = 0; i < priseNumber.length; i++) {
            System.out.println(priseNumber[i]);
        }*/

        //用户输入自己的号码
        int[] numberArr = numberArr(sc, resultRed);
        /*for (int i = 0; i < priseNumber.length; i++) {
            System.out.println(numberArr[i]);
        }*/

        //判断中奖的情况并记录
        int red = 0, blue = 0;
        red = redResult(priseNumber,numberArr,red);
        blue = blueResult(priseNumber,numberArr,blue);

        //输出中奖情况
        finalResult(red,blue);
    }

    public static int[] priseNumber(int[] resultRed) {
        //确定中奖号码
        Random ra = new Random();
        int[] arr = new int[7];

        //33个号码的乱序池子
        for (int k = 0, temp; k < resultRed.length; k++) {
            int randomIndex = ra.nextInt(resultRed.length);
            if (k != randomIndex) {
                temp = resultRed[k];
                resultRed[k] = resultRed[randomIndex];
                resultRed[randomIndex] = temp;
            }
        }
        //在乱序池子中取六个红球中奖号码
        for (int i = 0; i < 6; i++) {
            arr[i] = resultRed[i];
        }
        //随机取蓝球中奖号码
        arr[6] = ra.nextInt(16) + 1;
        return arr;
    }

    public static int[] numberArr(Scanner sc, int[] resultRed) {
        //用户输入自己购买的号码
        int[] numberArr = new int[7];
        for (int i = 0; i < 7; i++) {
            if (i < 6) {
                System.out.print("请输入您的第" + (i + 1) + "个红球号码：");
                while (true) {
                    int number = sc.nextInt();
                    //if判断防止重复输入和越界输入
                    if (number < 1 || number > 33) {
                        System.out.print("您输入的号码无效！请重新输入：");
                    } else if (resultRed[number] == 0) {
                        System.out.print("您输入的号码已存在！请重新输入：");
                    } else {
                        numberArr[i] = number;
                        resultRed[number] = 0;
                        break;
                    }
                }
            } else {
                System.out.print("请输入您的蓝球号码：");
                while (true) {
                    int number = sc.nextInt();
                    //防止越界输入
                    if (number < 1 || number > 33) {
                        System.out.print("您输入的号码无效！请重新输入：");
                    } else {
                        numberArr[6] = number;
                        break;
                    }
                }
            }
        }
        return numberArr;
    }

    public static int redResult(int[] priseNumber, int[] numberArr, int red){
        //判断红球中奖数量进行记录并输出
        for(int i = 0; i < 6; i++){
            for(int j = 0; j < 6; j++){
                if(numberArr[i] == priseNumber[j]){
                    red += 1;
                    break;
                }
            }
        }
        return red;
    }

    public static int blueResult(int[] priseNumber,int[] numberArr, int blue){
        if(numberArr[6] == priseNumber[6]){
            blue = 1;
        }
        return blue;
    }

    public static void finalResult(int red, int blue) {
//        System.out.println(red+" "+ blue);
        if ((red == 0 || red == 1 || red == 2 || red == 3 ) && blue == 0){
            System.out.print("很遗憾，您未中奖");
        } else if(red == 0 && blue == 1) {
            System.out.print("恭喜中奖！\n六等奖：奖金5元");
        } else if (red == 1 && blue == 1) {
            System.out.print("恭喜中奖！\n六等奖：奖金5元");
        } else if (red == 2 && blue == 1) {
            System.out.print("恭喜中奖！\n六等奖：奖金5元");
        } else if (red == 3 && blue == 1) {
            System.out.print("恭喜中奖！\n五等奖：奖金10元");
        } else if (red == 4 && blue == 0) {
            System.out.print("恭喜中奖！\n五等奖：奖金10元");
        } else if (red == 4 && blue == 1) {
            System.out.print("恭喜中奖！\n四等奖：奖金200元");
        } else if (red == 5 && blue == 0) {
            System.out.print("恭喜中奖！\n四等奖：奖金200元");
        } else if (red == 5 && blue == 1) {
            System.out.print("恭喜中奖！\n三等奖：奖金3000元");
        } else if (red == 6 && blue == 0) {
            System.out.print("恭喜中奖！\n二等奖：奖金500万元");
        } else {
            System.out.print("恭喜中奖！\n一等奖：奖金1000万元");
        }
    }

}
