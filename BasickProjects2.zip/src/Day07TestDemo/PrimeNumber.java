package Day07TestDemo;

public class PrimeNumber {
    public static void main(String[] args) {
        for(int i = 101;i <= 200;i++){
            if(primeNumber(i)) {
                System.out.print(i+"\t");
            }
        }
    }
    public static boolean primeNumber(int number){
        for (int i = 2; i <= number / 2; i++) {
            if(number % i == 0){
                return false;
            }
        }
        return true;
    }
}
