package Day07TestDemo;

import java.text.DecimalFormat;
import java.util.Scanner;

public class FinalScore {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        //定义总数
        int Sum = getSum();
        //求平均数
        DecimalFormat de = new DecimalFormat("0.00");
        String finalscore = de.format((double)Sum / 4);
        System.out.print(finalscore);
    }

    public static int getSum(){
        Scanner sc = new Scanner(System.in);
        int Sum = 0;
        int[] arr = new int[6];
        for (int i = 0; i < arr.length; ) {
                System.out.print("请输入第"+(i+1)+"个打分：");
                int temp = sc.nextInt();
                if(temp < 0 || temp > 100){
                    System.out.println("输入分数非法！请重新输入");
                }else{
                    arr[i] = temp;
                    Sum = Sum + arr[i];
                    i++;
                }
        }
        int max = maxScore(arr);
        int min = minScore(arr);
        Sum = Sum - max - min;
        return Sum;
    }

    public static int maxScore(int[] arr) {
        int temp = arr[0];
        for (int i = 0; i < arr.length; i++) {
            if (temp < arr[i]) {
                temp = arr[i];
            }
        }
        System.out.println(temp);
        return temp;
    }

    public static int minScore(int[] arr) {
        int temp = arr[0];
        for (int i = 0; i < arr.length; i++) {
            if (temp > arr[i]) {
                temp = arr[i];
            }
        }
        System.out.println(temp);
        return temp;
    }
}
