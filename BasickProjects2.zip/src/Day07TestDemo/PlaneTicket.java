package Day07TestDemo;

import java.util.Scanner;

public class PlaneTicket {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        while (true) {
            //输入机票月份
            System.out.print("请输入购票月份：");
            int month = sc.nextInt();
            if (month > 12 || month < 1) {
                System.out.println("ERROR!");
            } else {
                //输入舱室类型
                System.out.print("请输入舱室类型：");
                String type = sc.nextLine();
                type = sc.nextLine();
                if (type.equals("头等舱") || type.equals("经济舱")) {
                    //输入机票的价格
                    System.out.print("请输入机票原价：");
                    int price = sc.nextInt();
                    //planeTicket(price, month, type);
                    planeTicket(month, type, price);
                    break;
                } else {
                    System.out.println("ERROR!");
                }
                //System.out.print(price+"\t"+month+"\t"+type);
            }
        }
    }

    private static void planeTicket(int month, String type, int price) {
        if (5 <= month && month <= 10 && type.equals("头等舱")) {
            price *= 0.9;
        } else if (5 <= month && month <= 10 && type.equals("经济舱")) {
            price *= 0.85;
        } else if (type.equals("头等舱")) {
            price *= 0.7;
        } else {
            price *= 0.65;
        }
        System.out.print("最终价格为：" + price);
    }

    /*public static void planeTicket(int price, int month, String type) {
        if (5 <= month && month <= 10 && type.equals("头等舱")) {
            price *= 0.9;
        } else if (5 <= month && month <= 10 && type.equals("经济舱")) {
            price *= 0.85;
        } else if (type.equals("头等舱")) {
            price *= 0.7;
        } else {
            price *= 0.65;
        }
        System.out.print("最终价格为：" + price);
    }*/

}
