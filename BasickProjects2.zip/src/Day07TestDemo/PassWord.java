package Day07TestDemo;

import java.util.Scanner;

public class PassWord {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        //输入要加密的密码
        int password = sc.nextInt();
        //定义密码的位数，加密后的密码
        String wordpass = "";
        //对密码进行加密操作，获得加密后的密码
        int i = 1;
        while(password / i > 0){
            wordpass = wordpass + (((password / i % 10) + 5) % 10);
            i *= 10;
        }
        System.out.print(wordpass);
    }
}
