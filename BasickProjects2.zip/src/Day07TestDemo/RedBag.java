package Day07TestDemo;
//抽奖，随机出号，必中奖
import java.util.Random;

public class RedBag {
    public static void main(String[] args) {
        Random ra = new Random();

        /*
        一个数组

        int[] arr = {2,588,888,1000,10000};
        for (int i = 0; i < 5; i++) {
            int j = ra.nextInt(5);
            if(arr[j] > 0){
                System.out.println(arr[j]);
                arr[j] = 0;
            }else{
                i--;
            }
        }*/


        /*
        两个数组

        int[] brr = {52, 588, 888, 1000, 10000};
        int[] crr = new int[5];
        for (int i = 0; i < 5; i++) {
            int k = ra.nextInt(5);
            for (int f = 0; f < 5; ) {
                if (brr[k] != crr[f] && crr[f] == 0) {
                    crr[f] = brr[k];
                    System.out.println(brr[k]);
                    break;
                } else if(brr[k] != crr[f] && crr[f] != 0){
                    f++;
                }else if(brr[k] == crr[f]){
                    i--;
                    break;
                }else {
                    System.out.println(brr[k]);
                }
            }
        }*/


        //乱序输出的方法
        int[] arr = {52,588,888,1000,10000};
        int temp;
        for(int i = 0; i < ((arr.length+1) / 2); ){
            int k = ra.nextInt(5);
            if(i != k){
                temp = arr[i];
                arr[i] = arr[k];
                arr[k] = temp;
                i++;
            }
        }
        for (int i = 0; i < 5; i++) {
            System.out.print(arr[i]+" ");
        }
    }
}
