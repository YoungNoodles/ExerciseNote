package Day01;

import java.util.Scanner;

public class Palindrome_number {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("请输入要判断的数字：");
        int x = sc.nextInt();
        //定义结果、数字位数
        int length = 1, bit = 10;
        boolean resault = true;

        //确定位数
        while ((x / bit) > 0) {
            length++;
            bit *= 10;
        }
        System.out.print("是"+length+"位数\n");
        //设计两个数组分别正序、反序存储输入的数字
        int positive[] = new int[length];
        int inverted[] = new int[length];
        for (int i = 0, k = 1; i < length; i++) {
            inverted[i] = (int) (x / k % 10);
            positive[length - 1 - i] = (int) (x / k % 10);
            k *= 10;
        }
        /*for(int i = 0;i < length;i++){
            System.out.print(positive[i]+"\t");
        }
        for(int i = 0;i < length;i++){
            System.out.print(inverted[i]+"\t");
        }*/
        int roll = 0;
        for (int i = 0; i < length; i++) {
            if (positive[i] == inverted[i]) {
                roll += 1;
            } else {
                roll += 0;
            }
        }
        if (roll == length) {
            System.out.print(resault);
        } else {
            System.out.print(!resault);
        }
    }
}
