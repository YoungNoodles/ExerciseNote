package Day01;

import java.util.Scanner;

public class Subtraction_Division {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        //输入两个要相除的整数
        System.out.print("请输入被除数：");
        int number1 = sc.nextInt();
        System.out.print("请输入除数：");
        int number2 = sc.nextInt();
        int j = 0;
        for(;number1 >=number2;j++){
            number1 = number1 - number2;
        }
        System.out.print("商是："+j+"\n余数是："+number1);
    }
}
