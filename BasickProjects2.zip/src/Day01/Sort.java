package Day01;

import java.util.Scanner;

public class Sort {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("请输入要排序数组的大小：");
        int number=sc.nextInt();
        int arr[] = new int[number];
        int Max=arr[1];
        for (int i = 0;i < arr.length;i++) {
            System.out.print("输入第" + (i+1) + "个数：");
            arr[i] = sc.nextInt();
            if (Max <= arr[i]) {
                Max = arr[i];
            } else {
                Max = Max;
            };
            //System.out.println(Max);
        }
        System.out.println(Max);
    }
}
