package Day01;

import java.util.Scanner;

public class AddNumber {
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        //求和序列长度length、序列首项No_1、公差D
        System.out.print("请输入序列的长度：");
        int length=sc.nextInt()/*,i=0*/;
        System.out.print("请输入序列的首项：");
        double No_1=sc.nextDouble();
        System.out.print("请输入序列的公差：");
        double D=sc.nextDouble();
        double Sum=0;
        int i = 0;
        while(i<length){
            Sum=Sum+No_1;No_1=No_1+D;i++;
        }
        /*for(int i =0,Sum=0;i < length;i++){
            Sum +=No_1;No_1 +=D;
            System.out.println(Sum);
        }*/
        if(Sum % 1 > 0) {
            System.out.println(Sum);
        }else{
            System.out.println((int)Sum);
        }
    }
}
