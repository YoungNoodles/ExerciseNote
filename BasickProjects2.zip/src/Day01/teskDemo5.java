package Day01;

import java.util.Scanner;

public class teskDemo5 {
    public static void main(String[] args) {
        Scanner ssc = new Scanner(System.in);
        System.out.print("请输入第一个数字：");
        int a = ssc.nextInt();
        System.out.print("请输入第二个数字：");
        int b = ssc.nextInt();
        boolean result = a == 6 || b == 6 || (a + b) % 6 == 0;
        System.out.println(result);
    }
}
