package Day01;

public class TestDemo1 {
    public static void main(String[] args){
        int i = 0;
        double thickness = 0.1;
        while(thickness < 8844430){
            thickness *= 2; i++;
            System.out.print(thickness+"\t\t"+i+"\n");
        }
        System.out.print(i);
    }
}
