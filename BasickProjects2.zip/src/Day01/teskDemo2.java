package Day01;

public class teskDemo2 {
    public static void main(String[] args){
/*        Scanner sca=new Scanner(System.in);
        byte a=sca.nextByte();
        byte b=sca.nextByte();
        byte resault=(byte)(a+b);
        System.out.println(resault);*/
        int a=7412;
        String s = String.valueOf(a);
        StringBuilder stringBuilder = new StringBuilder(s);
        System.out.println(stringBuilder.reverse());
    }
}
