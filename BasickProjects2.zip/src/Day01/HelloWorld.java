package Day01;

import java.util.Scanner;

public class HelloWorld {
    public static void main(String[] args) {
        Scanner depart = new Scanner(System.in);
        System.out.print("请输入要拆分的三位数:");
        int number = depart.nextInt();
        int hun = number / 100 % 10;
        int ten = number / 10 % 10;
        int one = number % 10;
        int a = number / 100;
        if (10 > a & a > 0) {
            System.out.println("百位是：" + hun + "\n" + "十位是：" + ten + "\n" + "个位是：" + one);
            hun = ten++;
            System.out.println(hun);
            System.out.println(ten);
            hun = ++ten;
            System.out.println(hun);
            System.out.println(ten);
        }
        else System.out.println("该数不是三位数!");
    }
}
