package Day01;

import java.util.Scanner;

public class RankDown {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int c;
        System.out.print("请输入数组的长度：");
        int length = sc.nextInt();
        System.out.println("请输入整数组：");
        int rank[] = new int[length];
        for (int i = 0; i < length; i++) {
            rank[i] = sc.nextInt();
        }
        for (int j = 0; j < length; j++) {
            for (int k = 0; k < j; k++) {
                if (rank[j] > rank[k]) {
                    c = rank[k];
                    rank[k] = rank[j];
                    rank[j] = c;
                }
            }
        }
        for (int l = 0; l < length; l++) {
            System.out.println(rank[l]);
        }
    }
}
