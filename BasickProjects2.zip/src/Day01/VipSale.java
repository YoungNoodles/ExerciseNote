package Day01;

import java.util.Scanner;

public class VipSale {
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        System.out.print("请输入商品价格：");
        int price=sc.nextInt();
        System.out.print("请输入您的会员等级：");
        int vipLevel=sc.nextInt();
        if(vipLevel==1){
            System.out.println("应付金额为："+(int)(price*0.9));
        }else if(vipLevel==2) {
            System.out.println("应付金额为："+(int)(price*0.8));
        }else if(vipLevel==3){
            System.out.println("应付金额为："+(int)(price*0.7));
        }else{
            System.out.println("不打折，要打给你丫打骨折！");
        }
    }
}
