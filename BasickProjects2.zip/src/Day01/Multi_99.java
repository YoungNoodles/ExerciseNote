package Day01;

public class Multi_99 {
    public static void main(String[] args) {
        for (int j = 1, resault; j < 10; j++) {
            for (int k = 1; k <= j; k++) {
                if (k < j) {
                    resault = j * k;
                    System.out.print(j + "*" + k + "=" + resault + "\t");
                } else {
                    resault = j * k;
                    System.out.println(j + "*" + k + "=" + resault + "\t");
                }
            }
        }
    }
}
