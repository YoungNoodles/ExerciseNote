package Day01;

import java.util.Scanner;

public class teskDemo6 {
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        System.out.print("您的票号是:");
        int number=sc.nextInt();
        if(0<number&number<=100){
            if(number%2==0){
                System.out.println("坐右边");
            } else {
                System.out.println("坐左边");
            }} else{
            System.out.println("您持有的是假票！");
        }
        }
    }
