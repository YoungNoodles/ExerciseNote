package Day01;

import java.util.Scanner;

public class TestSport {
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        System.out.print("请输入今天是周几：");
        String day=sc.nextLine();
        switch (day){
            case"周一":
                System.out.print("今天的安排是：跑步");
                break;
            case"周二":
                System.out.print("今天的安排是：游泳");
                break;
            case"周三":
                System.out.print("今天的安排是：慢走");
                break;
            case"周四":
                System.out.print("今天的安排是：动感单车");
                break;
            case"周五":
                System.out.print("今天的安排是：拳击");
                break;
            case"周六":
                System.out.print("今天的安排是：爬山");
                break;
            case"周日":
                System.out.print("今天的安排是：好好吃一顿");
                break;
            default:
                System.out.print("你家一周里还有"+day+"？");
                break;
        }
    }
}
