package Day01;

import java.util.Scanner;

public class teskDemo3 {
    public static void main(String[] args){
        Scanner target=new Scanner(System.in);
        /*byte target=depart.nextByte();
        byte me=depart.nextByte();
        if(target<me) System.out.println("true");
        else System.out.println("false");*/
        System.out.print("请输入你的衣服时髦度:");
        byte myFashion=target.nextByte();
        System.out.print("请输入相亲对象的衣服时髦度:");
        byte targetFashion=target.nextByte();
        boolean resault=myFashion>targetFashion;
        System.out.println(resault);
    }
}
