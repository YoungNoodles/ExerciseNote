package Day01;

import java.util.Scanner;

public class Count_15 {
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        System.out.print("请输入下限：");
        int Low=sc.nextInt();
        System.out.print("请输入上限：");
        int Up=sc.nextInt();
        int c;
        //判断输入的上下限位置是否正确
        if(Low > Up){
            c = Low; Low = Up; Up = c;
        }
        int Count = 0;
        for(int i = Low; Low <= i && i <= Up; i++){
            if(i % 15 == 0){
                Count++;
            }
        }
        System.out.print("既可以被3整除又可以被5整除的数有"+Count+"个");
    }
}
