package Day06TestDemo;

import java.util.Scanner;

public class CopyOfRange {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int[] arr = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
        while(true){
            System.out.print("请输入起始位置：");
            int from = sc.nextInt();
            System.out.print("请输入结束位置：");
            int to = sc.nextInt();
            int[] copyarr = new int[to - from];
            if (from >= to || to > arr.length || from < 0) {
                System.out.println("ERROR!");
            } else {
                copyarr = copyOfRange(arr, from, to);
                printArr(copyarr);
                break;
            }
        }
    }

    public static int[] copyOfRange(int[] arr, int from, int to) {
        int[] copyarr = new int[to - from];
        for (int i = 0, j = from; j < to; i++, j++) {
            copyarr[i] = arr[j];
        }
        return copyarr;
    }

    public static void printArr(int[] arr) {
        for (int i = 0; i < arr.length; i++) {
            System.out.print(arr[i] + "\t");
        }
    }
}
