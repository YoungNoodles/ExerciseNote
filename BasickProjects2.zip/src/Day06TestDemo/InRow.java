package Day06TestDemo;

import java.util.Random;

public class InRow {
    public static void main(String[] args) {
        Random ra = new Random();
        for (int i = 0; i < 5; i++) {
            int j = ra.nextInt(6);
        }
    }

    public static void getSum(int number_1,int number_2){
        int Sum = number_1 + number_2;
    }
}
