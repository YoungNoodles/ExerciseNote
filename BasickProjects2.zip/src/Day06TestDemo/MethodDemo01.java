package Day06TestDemo;

import java.nio.channels.Pipe;
import java.util.Scanner;

public class MethodDemo01 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int sum = 0;
        for (int i = 0; i < 4; i++) {
            sum = sum + getSum();
        }
        System.out.println(sum);
    }

    public static int getSum() {
        Scanner sc = new Scanner(System.in);
        int add_1 = sc.nextInt();
        int add_2 = sc.nextInt();
        int add_3 = sc.nextInt();
        return add_1 + add_2 + add_3;
    }
}
