package Day06TestDemo;

import java.util.Scanner;

public class MethodDemo02 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("输入数组的长度：");
        int length = sc.nextInt();
        int[] arr = new int[length];
        arr = Array(arr);
        PrintArray(arr);
        }

    public static int[] Array(int[] arr) {
        Scanner sc = new Scanner(System.in);
        for (int i = 0; i < arr.length; i++) {
            System.out.print("输入arr["+i+"]的值");
            arr[i] = sc.nextInt();
        }
        return arr;
    }
    public static void PrintArray(int[] arr) {
        for (int i = 0; i < arr.length; i++) {
            System.out.print(arr[i] + "\t");
        }
    }
}
