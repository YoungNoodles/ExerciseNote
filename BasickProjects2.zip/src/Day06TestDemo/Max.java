package Day06TestDemo;

import java.util.Scanner;

public class Max {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        //定义数组的长度
        System.out.print("请输入数组长度：");
        int length = sc.nextInt();
        //初始化数组
        int[] arr = new int[length];
        arr = Insert(arr);
        System.out.print("数组最大值为："+Maxnum(arr));
    }

    public static int Maxnum(int[] arr) {
        int max = arr[0];
        for (int i = 0; i < arr.length; i++) {
            if(max < arr[i]){
                max = arr[i];
            }
        }
        return max;
    }

    public static int[] Insert(int[] arr) {
        Scanner sc = new Scanner(System.in);
        for (int i = 0; i < arr.length; i++) {
            System.out.print("请输入arr["+i+"]：");
            arr[i] = sc.nextInt();
        }
        return arr;
    }
}
