import java.util.Scanner;

public class test {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        /*
        字符串输入的测试
        字符串输入比较的测试

        Scanner sc = new Scanner(System.in);
        System.out.print("输入舱室类型：");
        String type = sc.nextLine();
        int number;
        if(type == "头等舱"){
            number = 1;
            System.out.println(number);
        }else{
            number = 0;
            System.out.println(number);
        }
        type = "头等舱";
        if(type == "头等舱"){
            number = 2;
            System.out.println(number);
        }*/

        /*
        字符串拼接的测试

        String bit = "";
        bit = bit + 1;
        System.out.print(bit);*/

        /*
        数字存入数组测试

        Scanner sc = new Scanner(System.in);
        int input = sc.nextInt();
        int length = Length(input);
        int[] password = passWord(length,input);
        //打印出存储密码的数组
        for (int i = 0; i < length; i++) {
            System.out.print(password[i]+" ");
        }
        public static int Length(int input){
        //获取输入数字的长度
        int i = 1;
        int length = 0;
        while(input / i > 0){
            length++;
            i *= 10;
        }
        return length;
    }

    public static int[] passWord(int length,int input){
        //将输入的数字正序放入数组中
        int[] password = new int[length];
        for(int i = length - 1,j = 1; i >= 0; i--, j *= 10){
            password[i] = input / j % 10;
        }
        return password;
    }*/



        /*
        转换测试，字符串转数字

        String number = "0234";
        int num = Integer.parseInt(number);
        System.out.println(num);
        char numb = '1';
        num = (int) (numb);
        System.out.println(num);*/

        //字符串判断条件测试
        /*Scanner sc = new Scanner(System.in);
        char a = sc.next().charAt(0);
        *//*if(a == '!'){
            System.out.println(1);
        }*//*
        int num = a - '0';
        System.out.println(num);*/

        /*Scanner sc = new Scanner(System.in);
         *//*int red = sc.nextInt();
        int blue = sc.nextInt();*//*
        String test = sc.nextLine();
        System.out.print(test);*/

        /*String s1 = "123";
        String s2 = sc.nextLine();
        String s3 = s2;

        if(s2 == s1){
            System.out.println(true);
        } else {
            System.out.println(false);
        }

        if(s3 == s1){
            System.out.println(true);
        } else {
            System.out.println(false);
        }

        if("abc".equals("abc")){
            System.out.println(true);
        }*/

        /*String s1 = "123";
        String s2 = new String(s1);
        System.out.printf("""
                %s
                %s
                """, s1, s2);*/

        /*String a1 = "0";
        int[] arr = {1,2,3,4};
        System.out.println(arr[Integer.parseInt(a1)]);*/

        /*StringBuilder sb = new StringBuilder();
        sb.append("abcdefghijklmnopqrstuvwxyz012345678");
        System.out.println(sb.capacity());
        System.out.println(sb.length());*/

        /*StringBuilder sb = new StringBuilder("abc");
        getSB(sb);
        System.out.println(sb);
    }

    public static void getSB(StringBuilder sb){
        sb.append("what");
        System.out.println(sb);*/

        /*for (int i = 0; i < 5;) {
            System.out.print(sc.nextLine());
            System.out.println(i);
            //i++;
            ++i;
            System.out.println(i);
        }*/

        char a = 65;
        StringBuilder sb = new StringBuilder();
        sb.append(a);
        System.out.println(sb);
        sb.append((char)(a + 32));
        System.out.println(sb);

    }
}
