package ArrayDemo;

import java.util.Random;

public class HelpABCD {
    public static void main(String[] args){

        //生成0、1、2、3四个随机数
        Random ra = new Random();
        int number = ra.nextInt(4);
        char[] arr = {'A','B','C','D'};
        System.out.println(arr[number]+"\n"+number);
    }
}
