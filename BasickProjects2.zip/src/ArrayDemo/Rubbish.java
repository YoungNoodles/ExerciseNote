package ArrayDemo;

import java.util.Random;

public class Rubbish {
    public static void main(String[] args){
        Random ra = new Random();
        int[] arr = {1,2,3,4,5};
        int temp;
        for (int i = 0; i < arr.length; i++) {
            int j = ra.nextInt(arr.length),k = ra.nextInt(arr.length);
            if(j != k){
                temp = arr[j];
                arr[j] = arr[k];
                arr[k] = temp;
            }
        }
        for (int i = 0; i < arr.length; i++) {
            System.out.print(arr[i]+"\t");
        }
    }
}
