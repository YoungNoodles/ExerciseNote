package ArrayDemo;

public class Exchange {
    public static void main(String[] args){
        int a = 5,b = 7;
        a = a - b;
        b = b + a;
        a = b - a;
        System.out.print(a+"\t"+b);
    }
}
