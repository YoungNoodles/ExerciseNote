package Day09;

import java.util.Random;

public class ZhangWuji {
    private String name = "【张无忌】";
    private int blood = 100;
    private String skill = "【乾坤大挪移】";

    public String getName() {
        return name;
    }

    public int getBlood() {
        return blood;
    }

    public String getSkill() {
        return skill;
    }

    public int attack(String name, int blood) {
        Random ra = new Random();
        if (blood > 25) {
            int attack = ra.nextInt(30) + 1;
            System.out.println("【张无忌】对" + name + "发动攻击！");
            if (attack < 19) {
                System.out.println("张无忌击中了" + name + "！\n");
                blood -= 5;
            } else if (attack < 25) {
                System.out.println(name + "躲开了【张无忌】的攻击！\n");
            } else {
                System.out.println("【张无忌】对" + name + "造成了暴击！\n");
                blood -= 10;
            }
        } else {
            System.out.println("【张无忌】对" + name + "使用【乾坤大挪移】！\n");
            blood = 0;
        }
        return blood;
    }
}
