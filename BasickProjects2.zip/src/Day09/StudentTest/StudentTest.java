package Day09.StudentTest;

import java.util.Scanner;

public class StudentTest {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        /*Student st_1 = new Student(18123874, "杨少达", 22);
        Student st_2 = new Student(18123876, "申晨阳", 22);
        Student st_3 = new Student(18123877, "秦思源", 22);*/

        //学生信息，学号唯一存在
        //按1遍历，输出所有学生信息
        //按2输入学号查询特定学生信息，若不存在则输出"学生不存在"
        //按3录入新的学生信息
        //按4输入学生学号删除学生信息，若存在则提示删除成功，不存在则提示"学生不存在"
        //按0退出程序

        //初始化数组
        Student[] student = new Student[10];
        for (int i = 0; i < student.length; i++) {
            student[i] = new Student();
        }

        //student[0] = new Student(11111111,"1",1);
        //student[1] = new Student(22222222,"2",2);
        //student[2] = new Student(33333333,"3",3);
        //student[3] = new Student(44444444,"4",4);
        //student[4] = new Student(55555555,"5",5);
        //student[5] = new Student(66666666,"6",6);
        //student[6] = new Student(77777777,"7",7);
        //student[7] = new Student(88888888,"8",8);
        //student[8] = new Student(99999999,"9",9);
        //student[9] = new Student(10000000,"10",10);

        //开始操作
        while (true) {
            showTips();
            System.out.print("请按提示选择要进行的操作：");

            int mode = sc.nextInt();
            if (mode == 1) {
                //输出所有学生信息
                showALL(student);
            } else if (mode == 2) {
                //查询特定学生信息
                selectStudent(sc, student);
            } else if (mode == 3) {
                //加入新学生的信息
                addStudent(sc, student);
            } else if (mode == 4) {
                //删除学生信息
                deleteStudent(sc, student);
            } else if (mode == 0) {
                //退出系统
                break;
            } else if (mode == 9) {
                //重新输出操作提示
                showTips();
            } else {
                System.out.println("您选择的操作无效，请重新输入：");
            }
        }
    }


    //操作提示
    private static void showTips() {
        System.out.println("""
                ##学号是八位整数##
                1.按【1】输出所有学生信息
                2.按【2】查询特定学生信息
                3.按【3】录入新学生信息
                4.按【4】删除学生信息
                5.按【9】重新显示操作提示
                6.按【0】退出系统
                """);
    }

    //##1.展示所有学生信息##
    private static void showALL(Student[] student) {
        int index = getIndex(student);
        System.out.println("现共有" + index + "个学生：");
        if (student[0].getStudentId() == 0) {
            System.out.println("NULL");
        } else {
            for (Student value : student) {
                if (value.getStudentId() != 0) {
                    value.readInformation();
                    System.out.println();
                }
            }
        }
    }

    /*限制学号
     * */
    public static int getStudentId(Scanner sc) {
        int studentId;
        while (true) {
            studentId = sc.nextInt();
            int length = 0;
            int bit = 1;
            while (studentId / bit > 0) {
                length += 1;
                bit *= 10;
            }
            if (length != 8) {
                System.out.println("无效的学号，请重新输入");
            } else {
                break;
            }
        }
        return studentId;
    }

    //##2.查找学生##
    private static void selectStudent(Scanner sc, Student[] student) {
        System.out.print("请输入要查询的学生学号：");
        int selectId = getStudentId(sc);
        for (Student value : student) {
            if (value.getStudentId() == selectId) {
                value.readInformation();
                System.out.println();
                return;
            }
        }
        System.out.println("学生不存在\n");
    }

    //判断新输入的学号是否已存在
    public static boolean contains(Student[] student, int studentId) {
        boolean flag = false;
        for (Student value : student) {
            if (value.getStudentId() == studentId) {
                flag = true;
                break;
            }
        }
        return flag;
    }

    //获取现在第一个空对象
    public static int getIndex(Student[] student) {
        int index = 0;
        for (Student value : student) {
            if (value.getStudentId() == 0) {
                break;
            } else {
                index += 1;
            }
        }
        return index;
    }

    //##3.添加学生##
    private static void addStudent(Scanner sc, Student[] student) {
        if (student[student.length - 1].getStudentId() != 0) {
            System.out.println("学生已满！无法添加");
        } else {
            while (true) {
                System.out.print("请输入要添加的学号：");
                int studentId = getStudentId(sc);
                boolean flag = contains(student, studentId);
                int index = getIndex(student);
                if (flag) {
                    System.out.println("输入的学号已存在！");
                } else {
                    student[index].setStudentId(studentId);
                    System.out.print("请输入学生的姓名：");
                    student[index].setName(sc.next());
                    System.out.print("请输入学生的年龄：");
                    student[index].setAge(sc.nextInt());
                    System.out.println("添加成功！\n");
                    break;
                }
            }
        }
    }

    //##4.删除学生##
    private static void deleteStudent(Scanner sc, Student[] student) {
        System.out.print("请输入要删除的学生的学号：");
        //定义一个变量，接收要删除学生的学号
        int deleteId = getStudentId(sc);
        //在对象数组中进行循环遍历
        for (int i = 0; i < student.length; i++) {
            //有学号和要删除的学号匹配
            if (student[i].getStudentId() == deleteId) {
                //对对象进行删除
                if (i < student.length - 1) {
                    for (int j = i; j < student.length - 1; j++) {
                        student[j] = student[j + 1];
                    }
                    System.out.println("学号为【" + deleteId + "】的学生已删除\n");
                    return;
                } else {
                    student[i] = new Student();
                    System.out.println("学号为【" + deleteId + "】的学生已删除\n");
                    return;
                }
            }
        }
        //没有学号匹配的情况
        System.out.println("学生不存在\n");
    }

}
