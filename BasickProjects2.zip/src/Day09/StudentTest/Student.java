package Day09.StudentTest;

public class Student {
    private int studentId;
    private String name;
    private int age;

    public Student() {
    }

    public Student(int studentId, String name, int age) {
        this.studentId = studentId;
        this.name = name;
        this.age = age;
    }

    public void setStudentId(int studentId) {
        this.studentId = studentId;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public int getStudentId() {
        return studentId;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public void readInformation() {
        //System.out.println("学号：" + studentId + "\n" + "姓名：" + name + "\n" + "年龄：" + age + "\n");
        System.out.printf("""
                学号：\t%S
                姓名：\t%s
                年龄：\t%s
                """,studentId,name,age);
    }
}
