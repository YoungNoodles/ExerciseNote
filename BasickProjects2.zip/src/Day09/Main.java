package Day09;

import java.sql.SQLOutput;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //创建角色，进行自动战斗
        //创建角色对象，然后进行战斗
        //角色有血量和技能，当对手剩余血量达到斩杀线将使用必杀技进行斩杀
        //普通攻击有概率打出暴击，造成两倍伤害，必杀技无法暴击
        Scanner sc = new Scanner(System.in);

        //定义包含角色名字、血量、技能的变量
        String roleP1;
        String roleP2;
        /*String roleP1 = "1";
        String roleP2 = "2";*/
        int bloodP1 = 100;
        int bloodP2 = 100;
        String skillP1;
        String skillP2;

        //输出游戏开始的提示
        System.out.println("""
                请按下列提示输入序号选择你的角色：
                1\t【乔峰】
                2\t【段誉】
                3\t【令狐冲】
                4\t【张无忌】
                """);

        //定义输入选择角色的代号
        int chooseP1;
        int chooseP2;

        //选择角色P1
        System.out.print("请P1选择角色：");
        while (true) {
            chooseP1 = sc.nextInt();
            GameRole grP1 = new GameRole();
            if (chooseP1 < 1 || chooseP1 > 4) {
                System.out.print("P1输入的角色序号无效，请重新输入！：");
            } else {
                roleP1 = getRoleP1(grP1,chooseP1);
                break;
            }
        }

        //选择角色P2
        System.out.print("请P2选择角色：");
        while (true) {
            chooseP2 = sc.nextInt();
            GameRole grP2 = new GameRole();
            if (chooseP2 < 1 || chooseP2 > 4) {
                System.out.print("P1输入的角色序号无效，请重新输入！：");
            } else if (chooseP2 == chooseP1) {
                System.out.print("P1已选择该角色！请重新选择：");
            } else {
                roleP2 = getRoleP2(grP2,chooseP2);
                break;
            }
        }

        bloodP1 = getBlood(chooseP1);
        bloodP2 = getBlood(chooseP2);

        skillP1 = getSkill(chooseP1);
        skillP2 = getSkill(chooseP2);

        //展示角色名字、血量和技能
        System.out.println(
                "角色信息：\n" +
                        "P1：姓名：" + roleP1 + "\t血量：" + bloodP1 + "\t技能：" + skillP1 + "\t\n" +
                        "P2：姓名：" + roleP2 + "\t血量：" + bloodP2 + "\t技能：" + skillP2);

        //战斗
        attack(chooseP1, chooseP2);

    }

    //获取第一个角色的名字
    private static String getRoleP1(GameRole grP1, int chooseP1) {
        String roleP1;
        grP1 = new GameRole(chooseP1);
        roleP1 = grP1.getName();
        System.out.println("P1选择的角色是 " + roleP1);
        return roleP1;
    }

    //获取第二个角色的名字，不能与第一个角色重复
    public static String getRoleP2(GameRole grP2, int chooseP2) {
        String roleP2;
        grP2 = new GameRole(chooseP2);
        roleP2 = grP2.getName();
        System.out.println("P2选择的角色是 " + roleP2);
        return roleP2;
    }

    public static int getBlood(int chooseP){
        GameRole grP = new GameRole(chooseP);
        int blood = grP.getBlood();
        return blood;
    }

    //获取选择角色的技能
    public static String getSkill(int chooseP) {
        GameRole grP = new GameRole(chooseP);
        return grP.getSkill();
    }

    //战斗方法
    //控制战斗的循环
    //回车键控制下一步
    //每次行动结束都要输出两个角色剩余血量
    //血量达到一定量将会进行斩杀
    public static void attack(int chooseP1, int chooseP2) {
        Scanner sc = new Scanner(System.in);
        GameRole grP1 = new GameRole(chooseP1);
        GameRole grP2 = new GameRole(chooseP2);
        String roleP1 = grP1.getName();
        String roleP2 = grP2.getName();
        int bloodP1 = grP1.getBlood();
        int bloodP2 = grP2.getBlood();

        while (true) {
            System.out.print("按下Enter键继续！");
            String jump = sc.nextLine();
            if (bloodP2 > 25) {
                bloodP2 = grP1.attack(chooseP1, bloodP2, roleP2);
                roleInformation(roleP1, bloodP1, roleP2, bloodP2);
            } else {
                bloodP2 = grP1.attack(chooseP1, bloodP2, roleP2);
                bloodP2 = 0;
                roleInformation(roleP1, bloodP1, roleP2, bloodP2);
                System.out.print("按下Enter键继续！");
                jump = sc.nextLine();
                System.out.println(roleP1 + "击败了" + roleP2 + "！战斗结束");
                break;
            }
            System.out.print("按下Enter键继续！");
            jump = sc.nextLine();
            if (bloodP1 > 25) {
                bloodP1 = grP2.attack(chooseP2, bloodP1, roleP1);
                roleInformation(roleP1, bloodP1, roleP2, bloodP2);
            } else {
                bloodP1 = grP2.attack(chooseP2, bloodP1, roleP1);
                System.out.println("按下Enter键继续！");
                roleInformation(roleP1, bloodP1, roleP2, bloodP2);
                jump = sc.nextLine();
                bloodP1 = 0;
                System.out.println(roleP2 + "击败了" + roleP1 + "！战斗结束");
                break;
            }
        }
    }

    private static void roleInformation(String roleP1, int bloodP1, String roleP2, int bloodP2) {
        System.out.println(
                "姓名：" + roleP1 + "\t血量：" + bloodP1 + "\t\n" +
                        "姓名：" + roleP2 + "\t血量：" + bloodP2);
    }

    /*public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        GameRole grP1 = getRoleP1(sc);
        System.out.printf("""
                        姓名：\t%s
                        血量：\t%s
                        技能：\t%s
                        
                        """,grP1.getName() , grP1.getBlood() , grP1.getSkill());
    }

    public static GameRole getRoleP1(Scanner sc) {
        int chooseP1 = sc.nextInt();
        GameRole grP1 = new GameRole(chooseP1);
        return grP1;
    }*/

}

