package Day09;

public class GameRole {

    String name;
    int blood;
    String skill;

    public GameRole() {
    }

    //有参初始化
    public GameRole(int number) {
        if (number == 1) {
            QiaoFeng qf = new QiaoFeng();
            name = qf.getName();
            blood = qf.getBlood();
            skill = qf.getSkill();
        } else if (number == 2) {
            DuanYu dy = new DuanYu();
            name = dy.getName();
            blood = dy.getBlood();
            skill = dy.getSkill();
        } else if (number == 3) {
            LinghuChong Lhc = new LinghuChong();
            name = Lhc.getName();
            blood = Lhc.getBlood();
            skill = Lhc.getSkill();
        } else {
            ZhangWuji zwj = new ZhangWuji();
            name = zwj.getName();
            blood = zwj.getBlood();
            skill = zwj.getSkill();
        }
    }

    public String getName() {
        return name;
    }

    public int getBlood() {
        return blood;
    }

    public String getSkill() {
        return skill;
    }

    //攻击方法
    public int attack(int number, int blood, String name){
        if(number == 1){
            //乔峰的攻击
            QiaoFeng qf = new QiaoFeng();
            blood = qf.attack(name,blood);
        } else if (number == 2) {
            //段誉的攻击
            DuanYu dy = new DuanYu();
            blood = dy.attack(name,blood);
        } else if (number == 3) {
            //令狐冲的攻击
            LinghuChong Lhc = new LinghuChong();
            blood = Lhc.attack(name,blood);
        } else {
            //张无忌的攻击
            ZhangWuji zwj = new ZhangWuji();
            blood = zwj.attack(name,blood);
        }
        return blood;
    }
}
