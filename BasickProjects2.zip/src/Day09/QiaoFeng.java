package Day09;

import java.util.Random;

public class QiaoFeng {
    private String name = "【乔峰】";
    private int blood = 100;
    private String skill = "【降龙十八掌】";

    public String getName() {
        return name;
    }

    public int getBlood() {
        return blood;
    }

    public String getSkill() {
        return skill;
    }

    public int attack(String name, int blood) {
        Random ra = new Random();
        if (blood > 25) {
            int attack = ra.nextInt(30) + 1;
            System.out.println("【乔峰】对" + name + "发动攻击！");
            if (attack < 19) {
                System.out.println("【乔峰】击中了" + name + "！\n");
                blood -= 5;
            } else if (attack < 25) {
                System.out.println(name + "躲开了【乔峰】的攻击！\n");
            } else {
                System.out.println("【乔峰】对" + name + "造成了暴击！\n");
                blood -= 10;
            }
        } else {
            System.out.println("【乔峰】对" + name + "使用【降龙十八掌】！\n");
            blood = 0;
        }
        return blood;
    }

}
