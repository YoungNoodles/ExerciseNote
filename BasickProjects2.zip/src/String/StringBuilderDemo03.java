package String;

public class StringBuilderDemo03 {
    public static void main(String[] args) {
        int[] arr = {1,2,3,3,4,2,5};
        //用StringBuilder字符串，在第一个数前加“[”
        StringBuilder sb = new StringBuilder("[").append(arr[0]);
        //循环遍历，加“，”和数组里的值
        for (int i = 1; i < arr.length; i++) {
            sb.append(",").append(arr[i]);
        }
        //在结尾加“]”
        sb.append("]");
        //转成字符串
        String str = sb.toString();
        System.out.println(str);
    }
}
