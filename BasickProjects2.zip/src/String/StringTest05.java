package String;

import java.util.Random;

public class StringTest05 {
    public static void main(String[] args) {
        Random ra = new Random();
        //存储大小写字母
        char[] arr = new char[52];
        for (int i = 0; i < 26; i++) {
            arr[i] = (char) (i + 65);
        }
        for (int i = 26; i < 52; i++) {
            arr[i] = (char) (i + 71);
        }
        //存储数字
        char[] numArr = new char[10];
        for(int i = 0; i < 10; i++){
            numArr[i] = (char) (i + 48);
        }
        //获得五位字母
        char[] result = new char[5];
        for (int i = 0; i < 5; i++) {
            int randomIndex = ra.nextInt(52);
            result[i] = arr[randomIndex];
        }
        //获得一个数字，替换掉一个字母
        int random = ra.nextInt(10);
        int index = ra.nextInt(5);
        result[index] = numArr[random];

        String str = new String(result);
        System.out.println(str);
    }
}
