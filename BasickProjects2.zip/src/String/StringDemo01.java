package String;

import java.util.Scanner;

public class StringDemo01 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String input = sc.next();
        int casea = 0;
        int caseA = 0;
        int casenum = 0;
        for (int i = 0; i < input.length(); i++) {
            char c = input.charAt(i);
            if('a' <= c && c <= 'z'){
                casea += 1;
            } else if('A' <= c && c <= 'Z'){
                caseA += 1;
            } else if('0' <= c && c <= '9'){
                casenum += 1;
            }
        }
        System.out.printf("""
                %s
                %s
                %s
                """,casea,caseA,casenum);
    }
}
