package String;

import java.util.Scanner;

public class StringDemo04 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String ABC = sc.nextLine();
        StringBuilder CBA = getCBA(ABC);
        System.out.println(CBA);
    }

    private static StringBuilder getCBA(String ABC) {
        StringBuilder CBA = new StringBuilder();
        for (int i = (ABC.length() - 1); i >= 0; i--) {
            CBA.append(ABC.charAt(i));
        }
        return CBA;
    }
}
