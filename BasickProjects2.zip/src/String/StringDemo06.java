package String;

import java.util.Scanner;

public class StringDemo06 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        String IdNumber;
        System.out.println("请输入您的身份证号：");
        while (true) {
            IdNumber = sc.nextLine();
            if (IdNumber.length() != 18) {
                System.out.println("您输入的身份证号码非法！请重新输入！");
            } else {
                break;
            }
        }

        String year = IdNumber.substring(6, 10);
        String month = IdNumber.substring(10, 12);
        String day = IdNumber.substring(12, 14);
        int genderId = Integer.parseInt(IdNumber.substring(16, 17));

        char gender;
        if (genderId % 2 == 0) {
            gender = '女';
        } else {
            gender = '男';
        }
        System.out.printf("""
                生日：\t%s年%s月%s日
                性别：\t%s
                """, year, month, day, gender);
    }
}
