package String;

import java.util.Scanner;

public class StringDemo08 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String talk = sc.nextLine();

        String[] arr = {"TMD","tmd","cnm","CNM","臭傻逼","傻逼","操你妈","妈逼","sb","SB","死妈孤儿"};
        int length;
        for (int i = 0; i < arr.length; i++) {
            length = arr[i].length();
            String code = "*";
            for (int j = 0; j < length; j++) {
                code += "*";
            }
            talk = talk.replace(arr[i],code);
        }

        System.out.println(talk);

    }
}
