package String;

import java.util.Scanner;

public class StringTest06 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String num1 = sc.nextLine();
        String num2 = sc.nextLine();

        char[] numArr1 = num1.toCharArray();
        char[] numArr2 = num2.toCharArray();

        int number1 = 0;
        int number2 = 0;

        for (int i = 0; i < numArr1.length; i++) {
            number1 = number1 * 10 + (numArr1[i] - 48);
        }

        for (int i = 0; i < numArr2.length; i++) {
            number2 = number2 * 10 + (numArr2[i] - 48);
        }

        int result = number1 * number2;
        System.out.println(result);
    }
}
