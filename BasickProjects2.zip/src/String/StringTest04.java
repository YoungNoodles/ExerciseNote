package String;

import java.util.Random;
import java.util.Scanner;

public class StringTest04 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Random ra = new Random();
        String str = sc.nextLine();
        //定义字符数组对字符串进行存储
        char[] arr = str.toCharArray();
        //对字符数组arr进行乱序操作
        getNewArray(ra, arr);
        //定义新的字符串接收乱序之后的字符数组arr
        String result = new String(arr);
        System.out.println(result);
    }

    /**
     * 对字符数组arr进行乱序处理
     * @param ra
     * @param arr
     */
    public static void getNewArray(Random ra, char[] arr){
        for (int i = 0; i < arr.length; i++) {
            int random = ra.nextInt(arr.length);
            char temp;
            temp = arr[i];
            arr[i] = arr[random];
            arr[random] = temp;
        }
    }
}
