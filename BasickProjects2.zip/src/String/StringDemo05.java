package String;

import java.util.Scanner;

public class StringDemo05 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.print("请输入要转换的数字：");
            String number = sc.nextLine();
            if (number.length() > 7) {
                System.out.println("输入数字超出范围！");
            } else if (number.length() == 0) {
                System.out.println("请输入有效数字！");
            } else {
                int length = number.length();
                String[] numberArr = getNumArr(number);
                String numCase = getNumCase(numberArr,length);
                System.out.println("最终结果是：\n" + numCase);
                break;
            }
        }
    }

    public static String[] getNumArr(String number){
        String[] numArr = new String[7];
        for (int i = 0; i < number.length(); i++) {
            numArr[i] = number.charAt(i) + "";
        }
        return numArr;
    }

    public static String getNumCase(String[] numberArr, int length) {
        String numCase = "";
        if (length == 1) {
            numCase = "零佰零拾零万零仟零佰零拾";
            numCase = numCase + numChange(numberArr,length);
        } else if (length == 2) {
            numCase = "零佰零拾零万零仟零佰";
            numCase = numCase + numChange(numberArr,length);
        } else if (length == 3) {
            numCase = "零佰零拾零万零仟";
            numCase = numCase + numChange(numberArr,length);
        } else if (length == 4) {
            numCase = "零佰零拾零万";
            numCase = numCase + numChange(numberArr,length);
        } else if (length == 5) {
            numCase = "零佰零拾";
            numCase = numCase + numChange(numberArr,length);
        } else if (length == 6) {
            numCase = "零佰";
            numCase = numCase + numChange(numberArr,length);
        } else {
            numCase = numCase + numChange(numberArr,length);
        }
        return numCase;
    }

    public static String numChange(String[] numberArr, int length) {
        char[] Number = {'零', '壹', '贰', '叁', '肆', '伍', '陆', '柒', '捌', '玖'};
        char[] Unit = {'圆', '拾', '佰', '仟', '万', '拾', '佰'};
        String numCase = "";
        for (int i = 0; i < length; i++) {
            for (int j = Number.length - 1; j >= 0; j--) {
                if (Integer.parseInt(numberArr[i]) == j) {
                    numCase += "" + Number[j] + Unit[6 - i];
                    /*System.out.printf("""
                            Number[j]:\t%s
                            Unit[i]:\t%s
                            numCase:\t%s
                            """,Number[j],Unit[i],numCase);*/
                }
            }
        }
        return numCase;
    }

}

