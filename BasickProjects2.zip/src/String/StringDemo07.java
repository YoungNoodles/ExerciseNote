package String;

import java.util.Scanner;

public class StringDemo07 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String phoneNumber = sc.nextLine();

        String mid = phoneNumber.substring(3,7);

        phoneNumber = phoneNumber.replace(mid,"****");

        System.out.println(phoneNumber);
    }
}
