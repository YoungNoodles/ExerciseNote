package String;

import java.util.Scanner;

public class StringBuilderDemo01 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        StringBuilder sb = new StringBuilder();
//添加字符串
        sb.append(sc.nextLine());
        System.out.println(sb);
//反转字符串
        sb.reverse();
        System.out.println(sb);
//StringBuilder类型字符串也有截取
        String str = sb.substring(0,(sb.length() - 1));
        System.out.println(str);
//转换成字符串
        String tab = sb.toString();
        tab += " fuck you !";
        System.out.println(tab);

    }

}
