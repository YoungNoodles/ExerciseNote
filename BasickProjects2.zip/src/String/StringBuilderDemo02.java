package String;

import java.util.Scanner;

public class StringBuilderDemo02 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        //键盘录入字符
        String str = getString(sc);
        //获得反转的字符串
        String rts = new StringBuilder(str).reverse().toString();
        //比较两字符串是否一致
        getResult(str,rts);
    }

    public static String getString(Scanner sc){
        return sc.nextLine();
    }

    public static void getResult(String str, String rts){
        if(str.equals(rts)){
            System.out.println("是对称字符串");
        }else{
            System.out.println("不是对称字符串");
        }
    }
}
