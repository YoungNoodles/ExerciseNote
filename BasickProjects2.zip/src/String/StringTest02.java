package String;

public class StringTest02 {
    public static void main(String[] args) {
        String str01 = "abcde";
        String str02 = "cdeab";
        boolean result = getResult(str01, str02);
        System.out.println(result);
        System.out.println(str01 + " " + str02);
    }

    /**
     *
     * @param str01
     * @param str02
     * @return
     */
    public static boolean getResult(String str01, String str02) {
        for (int i = 0; i < str01.length(); i++) {
            if (str01.equals(str02)) {
                return true;
            } else {
                StringBuilder sb = new StringBuilder(str01);
                char head = sb.charAt(0);
                /*sb = getNewSb(sb, head);
                str01 = sb.toString();*/
                str01 = getNewSb(sb,head);
            }
        }
        return false;
    }

    /**
     *
     * @param sb
     * @param head
     * @return
     */
    public static String/*Builder*/ getNewSb(StringBuilder sb, char head) {
        /*sb = new StringBuilder(sb.substring(1));
        sb.append(head);*/
        return (sb.substring(1) + head);
    }
}
