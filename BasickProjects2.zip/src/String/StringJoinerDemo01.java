package String;

import java.util.StringJoiner;

public class StringJoinerDemo01 {
    public static void main(String[] args) {
        //新建joiner字符串
        StringJoiner sjr = new StringJoiner(",","[","]");
        //添加字符串
        sjr.add("aaa").add("bbb").add("ccc");
        //求长度
        int len = sjr.length();
        //转成字符串
        String str = sjr.toString();
        System.out.println(str + " " + len);
    }
}
