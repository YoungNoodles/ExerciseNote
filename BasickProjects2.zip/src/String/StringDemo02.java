package String;

import java.util.Scanner;

public class StringDemo02 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int[] arr = new int[1];
        String s = getString(arr);
        System.out.println(s);
    }

    private static String getString(int[] arr) {
        String s = "[";
        if (arr == null){
            return "";
        }
        if(arr.length == 0){
            return "[]";
        }
        for (int i = 0; i < arr.length; i++) {
            if(i == 0){
                s = s + arr[i];
            }else{
                s = s + "," + arr[i];
            }
        }
        s = s + "]";
        return s;
    }
}
