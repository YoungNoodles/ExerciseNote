package String;

import java.util.Scanner;
import java.util.StringJoiner;

public class StringTest01 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String[] arr = {"", "Ⅰ", "Ⅱ", "Ⅲ", "Ⅳ", "Ⅴ", "Ⅵ", "Ⅶ", "Ⅷ", "Ⅸ",};
        //定义一个字符串，接收输入的，符合要求的字符串
        String str = getString(sc);
        //定义一个字符串，接收变换后的字符串
        String roman = getRoman(str, arr);
        //打印结果
        System.out.printf("""
                最终结果为%s
                """, roman);
    }

    /**
     * 方法说明：判断输入是否符合要求并返回适合的输入值
     * @param sc
     * @return
     */
    private static String getString(Scanner sc) {
        String str;
        while (true) {
            System.out.println("请输入要转换的数字：");
            StringBuilder sb = new StringBuilder(sc.nextLine());
            //限制数字的标记
            boolean flag = getFlag(sb);
            if (sb.length() > 9) {
                //限制长度
                System.out.println("输入长度超过规定长度，请重新输入！");
            } else if (flag) {
                str = sb.toString();
                break;
            } else {
                System.out.println("输入中含有其他符号，请重新输入！");
            }
        }
        return str;
    }

    /**
     * 方法说明：判断是否存在数字之外的字符
     * @param sb
     * @return
     */
    public static boolean getFlag(StringBuilder sb) {
        boolean flag = true;
        for (int i = 0; i < sb.length(); i++) {
            if (sb.charAt(i) < 48 || sb.charAt(i) > 57) {
                flag = false;
                return flag;
            }
        }
        return flag;
    }

    /**
     * 方法说明：一一比对，将阿拉伯数字转换成罗马数字
     * @param str
     * @param arr
     * @return
     */
    public static String getRoman(String str, String[] arr) {
        StringJoiner stj = new StringJoiner(" ", "[", "]");
        int number = Integer.parseInt(str);

        int tip = 1;
        for (int i = 1; i < str.length(); i++) {
            tip *= 10;
        }

        for (int i = 0; i < str.length(); i++) {
            stj.add(arr[number / tip % 10]);
            tip /= 10;
        }
        return stj.toString();
    }
}
