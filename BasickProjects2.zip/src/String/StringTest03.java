package String;

import java.util.Random;
import java.util.Scanner;

public class StringTest03 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Random ra = new Random();
        StringBuilder result = new StringBuilder();
        String strIn = sc.nextLine();
        int len = strIn.length();
        for (int i = 0; i < len; i++) {
            int step = ra.nextInt(strIn.length());
            //挑出第随机个索引
            result.append(strIn.charAt(step));
            //挑出随机索引后产生新的字符串
            strIn = getStringIn(strIn, step);
        }
        System.out.println(result);
    }

    /**
     * 将随机索引之前和之后的字符串拼接起来
     * @param strIn
     * @param step
     * @return
     */
    private static String getStringIn(String strIn, int step) {
        return strIn.substring(0, step) + strIn.substring(step + 1);
    }
}
