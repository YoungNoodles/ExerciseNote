package String;

import java.util.Scanner;

public class StringDemo03 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String[] data = new String[1];
        while (true) {
            String input = sc.nextLine();
            int length = input.length();
            int flag = 0;
            for (int i = 0; i < length; ) {
                if (input.charAt(i) == ' ') {
                    data = longerArr(data);
                    flag += 1;
                    i++;
                } else if(input.charAt(i) != '#') {
                    data[flag] += input.charAt(i);
                    i++;
                } else {
                    break;
                }
            }
            break;
        }
        for (String datum : data) {
            System.out.println(datum);
        }
    }

    public static String[] longerArr(String[] data) {
        String[] newData = new String[data.length + 1];
        System.arraycopy(data, 0, newData, 0, data.length);
        return newData;
    }
}
