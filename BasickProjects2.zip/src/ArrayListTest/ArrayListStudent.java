package ArrayListTest;

import java.util.ArrayList;
import java.util.Scanner;

public class ArrayListStudent {
    static ArrayList<User> users = new ArrayList<>();
    static ArrayList<ArrayListTest.Student> student = new ArrayList<>();

    //静态代码块，数据初始化
    static {
        User user1 = new User("1111", "user", "123123");

        users.add(user1);

        Student s1 = new Student("0001", "张三", "1");
        Student s2 = new Student("0002", "李四", "2");
        Student s3 = new Student("0003", "王五", "3");
        Student s4 = new Student("0004", "赵六", "4");
        Student s5 = new Student("0005", "陈四", "5");

        student.add(s1);
        student.add(s2);
        student.add(s3);
        student.add(s4);
        student.add(s5);
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        loop:
        while (true) {
            showFunction();
            int mode = sc.nextInt();
            switch (mode) {
                case 1 -> {
                    if (Login(sc, users)) {
                        mainMethod(sc, student);
                    } else {
                        System.out.println("用户名或密码错误！");
                    }
                }
                case 2 -> Register(sc, users);
                case 3 -> reSetPassword(sc, users);
                case 0 -> {
                    break loop;
                }
            }
        }

    }

    /**
     * 功能提示
     */
    public static void showFunction() {
        System.out.println("""
                ##欢迎使用菜鸟学生管理系统##
                1.按【1】登录
                2.按【2】注册
                3.按【3】忘记密码
                4.按【0】退出系统
                """);
    }

    /**
     * 登录功能
     *
     * @param sc
     * @param users
     */
    public static boolean Login(Scanner sc, ArrayList<User> users) {
        System.out.println("请输入UID：");
        String userId = sc.next();
        System.out.println("请输入密码：");
        String password = sc.next();

        if (userContains(users, userId)) {
            if (equalPassword(users, getUseIndex(users, userId), password)) {
                System.out.println("欢迎回来！ " + users.get(getUseIndex(users, userId)).getUsername());
                return true;
            }
        } else {
            return false;
        }
        return false;
    }

    /**
     * 注册功能
     *
     * @param sc
     * @param users
     */
    public static void Register(Scanner sc, ArrayList<User> users) {
        while (true) {
            //定义变量接收新的UID，用户名，密码
            System.out.println("请输入UID：");
            String newUID = sc.next();
            System.out.println("请输入用户名：");
            String newUserName = sc.next();
            System.out.println("请输入密码：");
            String password = sc.next();
            //判断该用户是否已存在，若存在，则重新输入，若不存在，则注册成功
            if (userContains(users, newUID)) {
                System.out.println("该UID已存在！请重新输入：");
            } else {
                User user = new User(newUID, newUserName, password);
                users.add(user);
                System.out.println("注册成功！");
                break;
            }
        }
    }

    /**
     * 忘记密码功能
     *
     * @param sc
     * @param users
     */
    public static void reSetPassword(Scanner sc, ArrayList<User> users) {
        while (true) {
            //定义一个字符串接收新的UID
            System.out.println("请输入UID：");
            String UID = sc.next();
            //对UID进行判断，存在则输入新密码，不存在则重新输入
            if (userContains(users, UID)) {
                System.out.println("请输入新的密码：");
                String password = sc.next();
                users.get(getUseIndex(users, UID)).setPassword(password);
                System.out.println("密码重置成功！");
                break;
            } else {
                System.out.println("UID错误！");
            }
        }
    }

    /**
     * 主要方法，登录成功后进入该方法
     *
     * @param sc
     * @param student
     */
    private static void mainMethod(Scanner sc, ArrayList<Student> student) {
        showTips();

        loop:
        while (true) {

            System.out.print("请按提示选择要进行的操作：");

            int mode = sc.nextInt();

            switch (mode) {
                case 1 -> showALL(student);//输出全部学生对象
                case 2 -> selectStudent(sc, student);//查找特定学生对象
                case 3 -> addStudent(sc, student);//添加学生
                case 4 -> deleteID(sc, student);//删除学生
                case 5 -> deleteName(sc, student);//根据名字删除学生
                case 6 -> changeStudent(sc, student);//修改学生信息
                case 9 -> showTips();
                case 0 -> {
                    break loop;
                }//退出系统
                default -> System.out.println("您选择的操作无效，请重新输入");
            }
        }
    }

    /**
     * 操作提示
     */
    private static void showTips() {
        System.out.println("""
                ##学号是四位字符串##
                1.按【1】输出所有学生信息
                2.按【2】查询特定学生信息
                3.按【3】录入新学生信息
                4.按【4】删除学生信息
                5.按【9】重新显示操作提示
                6.按【0】退出登录
                """);
    }

    /**
     * 【1】显示所有学生信息
     *
     * @param student
     */
    public static void showALL(ArrayList<ArrayListTest.Student> student) {
        if (student.size() == 0) {
            System.out.println("当前没有学生！\n");
        } else {
            System.out.println("共有" + student.size() + "个学生");
            for (Student value : student) {
                System.out.printf("""
                        学号：%s
                        姓名：%s
                        年龄：%s
                                                
                        """, value.getStudentId(), value.getName(), value.getAge());
            }
        }
    }

    /**
     * 【2】查询特定学生的信息
     *
     * @param sc
     * @param student
     */
    public static void selectStudent(Scanner sc, ArrayList<Student> student) {
        if (student.size() == 0) {
            System.out.println("当前没有学生！");
        } else {
            System.out.println("请输入要查询的学号：");
            //定义一个字符串接收要查询的学号，并检验学号是否合法
            String selectId = checkId(sc);
            if (stuContains(student, selectId)) {
                int index = getStuIndex(student, selectId);
                System.out.printf("""
                        学号：%s
                        姓名：%s
                        年龄：%s
                                                
                        """, student.get(index).getStudentId(), student.get(index).getName(), student.get(index).getAge());
            } else {
                System.out.println("该学生不存在\n");
            }
        }
    }

    /**
     * 【3】添加学生
     *
     * @param sc
     * @param student
     */
    public static void addStudent(Scanner sc, ArrayList<Student> student) {
        System.out.println("请输入要添加的学号：");
        //定义一个字符串接收要添加的学号
        String addId;
        //进行添加的操作

        //检验输入的学号是否合法
        addId = checkId(sc);
        //检验该学号是否已存在
        if (stuContains(student, addId)) {
            System.out.println("该学生已存在！");
        } else {
            Student stu = new Student();
            student.add(stu);
            stu.setStudentId(addId);
            System.out.println("请输入要添加的学生姓名：");
            addId = sc.next();
            stu.setName(addId);
            System.out.println("请输入要添加的学生年龄：");
            addId = sc.next();
            stu.setAge(addId);
            System.out.println("添加成功！\n");

        }
    }

    /**
     * 【4】删除学生
     *
     * @param sc
     * @param student
     */
    public static void deleteID(Scanner sc, ArrayList<Student> student) {
        System.out.println("请输入要删除学生的学号：");
        String deleteId = checkId(sc);
        if (!stuContains(student, deleteId)) {
            System.out.println("要删除的学生不存在！");
        } else {
            //student.removeIf(value -> value.getStudentId().equals(deleteId));
            student.remove(getStuIndex(student, deleteId));
            System.out.println("删除成功！\n");
        }
    }

    /**
     * 【5】按名字删除学生
     *
     * @param sc
     * @param student
     */
    public static void deleteName(Scanner sc, ArrayList<Student> student) {
        System.out.println("输入要模糊查询删除的关键字：");
        String deleteName = sc.next();
        ArrayList<Integer> index = equalName(student, deleteName);
        if (index.size() > 0) {
            for (int i = index.size() - 1; i >= 0; i--) {
                student.remove((int) (index.get(i)));
            }
            System.out.println("删除成功！");
        } else {
            System.out.println("未搜索到包含该关键字的对象！");
        }
    }

    /**
     * 【6】修改学生信息
     *
     * @param sc
     * @param student
     */
    public static void changeStudent(Scanner sc, ArrayList<Student> student) {

        System.out.println("输入要修改学生的学号：");
        String Id = checkId(sc);

        if (stuContains(student, Id)) {
            int index = getStuIndex(student, Id);

            System.out.println("输入修改后的姓名：");
            student.get(index).setName(sc.next());

            System.out.println("输入修改后的年龄：");
            student.get(index).setAge(sc.next());

            System.out.println("修改成功！");

        } else {
            System.out.println("该学生不存在！");
        }
    }

    /**
     * 验证学号是否合法
     *
     * @param sc
     * @return
     */
    public static String checkId(Scanner sc) {
        String str;
        while (true) {
            str = sc.next();
            if (str.length() != 4) {
                System.out.println("输入的学号不合法，请重新输入");
            } else {
                break;
            }
        }
        return str;
    }

    /**
     * 检验学号的唯一性
     *
     * @param student
     * @param Id
     * @return
     */
    public static boolean stuContains(ArrayList<Student> student, String Id) {
        for (Student value : student) {
            if (value.getStudentId().equals(Id)) {
                return true;
            }
        }
        return false;
    }

    /**
     * 检验输入的用户ID是否存在
     *
     * @param users
     * @param Id
     * @return
     */
    public static boolean userContains(ArrayList<User> users, String Id) {
        for (User value : users) {
            if (value.getId().equals(Id)) {
                return true;
            }
        }
        return false;
    }

    /**
     * 获取要进行操作的学生集合索引
     *
     * @param student
     * @param str
     * @return
     */
    public static int getStuIndex(ArrayList<Student> student, String str) {
        for (int i = 0; i < student.size(); i++) {
            if (student.get(i).getStudentId().equals(str)) {
                return i;
            }
        }
        return -1;
    }

    /**
     * 获取要进行操作的用户集合索引
     *
     * @param users
     * @param Id
     * @return
     */
    public static int getUseIndex(ArrayList<User> users, String Id) {
        for (int i = 0; i < users.size(); i++) {
            if (users.get(i).getId().equals(Id)) {
                return i;
            }
        }
        return -1;
    }

    /**
     * 判断密码是否正确
     *
     * @param users
     * @param index
     * @param password
     * @return
     */
    public static boolean equalPassword(ArrayList<User> users, int index, String password) {
        return users.get(index).getPassword().equals(password);
    }

    /**
     * 模糊查询所有符合条件的索引，返回这些索引的集合
     *
     * @param student
     * @param deleteName
     * @return
     */
    public static ArrayList<Integer> equalName(ArrayList<Student> student, String deleteName) {
        ArrayList<Integer> index = new ArrayList<>();
        for (int i = 0; i < student.size(); i++) {
            if (student.get(i).getName().contains(deleteName)) {
                index.add(i);
            }
        }
        return index;
    }
}

