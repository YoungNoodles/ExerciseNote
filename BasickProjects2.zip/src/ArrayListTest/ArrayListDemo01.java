package ArrayListTest;

import java.util.ArrayList;
import java.util.Scanner;

public class ArrayListDemo01 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ArrayList<String> listStr = new ArrayList<>();
        ArrayList<Integer> listInt = new ArrayList<>();
        /*list.add(sc.nextLine());
        list.add(sc.nextLine());
        list.add(1,sc.nextLine());
        System.out.println(list);*/

        /*list.add("aaa");
        list.add("aaa");
        list.add("ccc");
        list.add("ddd");

        StringJoiner sj = new StringJoiner(",","[","]");
        for (int i = 0; i < list.size(); i++) {
            sj.add(list.get(i));
        }
        System.out.println(sj);
        //有相同元素只会删除一个
        list.remove("aaa");
        System.out.println(list);*/


        /*listInt.add(123);
        listInt.add(456);
        System.out.println(listInt);*/

    }
}
