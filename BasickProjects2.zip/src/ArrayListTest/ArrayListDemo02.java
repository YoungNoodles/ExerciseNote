package ArrayListTest;

import java.util.ArrayList;
import java.util.Scanner;

public class ArrayListDemo02 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ArrayList<User> listUser = new ArrayList<>();
        for (int i = 0; i < 3; i++) {
            User newUser = new User();
            newUser.setId(sc.nextLine());
            newUser.setUsername(sc.nextLine());
            newUser.setPassword(sc.nextLine());
            listUser.add(newUser);
        }

        String targetId = sc.nextLine();
        int contains = checkExist(listUser, targetId);
        if(contains < 0){
            System.out.println("您搜索的用户不存在");
        }else{
            System.out.printf("""
                    Id:%s
                    Name:%s
                    Password:%s
                    
                    """,listUser.get(contains).getId(),listUser.get(contains).getUsername(),listUser.get(contains).getPassword());
        }
    }

    public static int checkExist(ArrayList<User> listUser, String targetId){

        for (int i = 0; i < listUser.size(); i++) {
            if(listUser.get(i).getId().equals(targetId)){
                return i;
            }
        }
        return -1;
    }
}
