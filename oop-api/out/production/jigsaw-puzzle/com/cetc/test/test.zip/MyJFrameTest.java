package com.CETC.test;

public class MyJFrameTest {
    public static void main(String[] args) {
        new MyJFrame();
    }
}
