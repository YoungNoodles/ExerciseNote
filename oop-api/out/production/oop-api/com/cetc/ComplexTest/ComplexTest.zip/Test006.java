package com.cetc.ComplexTest;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Calendar;
import java.util.Date;
import java.util.Scanner;

public class Test006 {
    public static void main(String[] args) throws ParseException {
        //用月份的方法判断平年闰年
        //JDK7的做法
        Scanner sc = new Scanner(System.in);
        //输入年份
        String str = sc.nextLine();
        //变成二月
        String February = str + "-2";
        //变成三月
        String March = str + "-3";
        //解析输入的年月，变成Date对象，创建日历对象
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM");
        //Date d2 = sdf.parse(February);
        //Date d3 = sdf.parse(March);
        Calendar cal2 = Calendar.getInstance();
        cal2.setTime(sdf.parse(February));
//        System.out.println(cal2);

        Calendar cal3 = Calendar.getInstance();
        cal3.setTime(sdf.parse(March));
//        System.out.println(cal3);
        //判断
        if ((cal3.getTimeInMillis() - cal2.getTimeInMillis()) / 1000 / 60 / 60 / 24 == 29) {
            System.out.println(str + "年是闰年");
        } else {
            System.out.println(str + "年是平年");
        }
        System.out.println("------------------------------------------------------------------");

        //JDK8做法
        //设置LocalDate对象
        int year = sc.nextInt();
        //当年二月的对象
        LocalDate ld2 = LocalDate.of(year, 2, 1);
        //当年三月的对象
        LocalDate ld3 = LocalDate.of(year, 3, 1);
        //判断是否是29天
        if (ChronoUnit.DAYS.between(ld2, ld3) == 29) {
            System.out.println(year + "年是闰年");
        } else {
            System.out.println(year + "年是平年");
        }
    }
}
