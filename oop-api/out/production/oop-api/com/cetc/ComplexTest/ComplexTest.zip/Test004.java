package com.cetc.ComplexTest;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.Scanner;

public class Test004 {
    public static void main(String[] args) throws ParseException {
        //计算到今天活了多少天
        //JDK7的做法
        //生日字符串
//        Scanner sc = new Scanner(System.in);
//        System.out.println("按照yyyy/MM/dd的格式输入生日");
//        String birthday = sc.nextLine();
        String birthday = "2000/05/06";
        //按生日的写法定义格式化对象
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
        //解析生日字符串，生成生日Date对象
        Date d = sdf.parse(birthday);
        //获取今天的Date对象
        Date today = new Date();
//        System.out.println(d.getTime());
        //获取毫秒值后相减，换算成天
        System.out.println((today.getTime() - d.getTime()) / 1000 / 60 / 60 /24);
        System.out.println("--------------------------------------------------------");

        //JDK8的做法
        //设置生日的年月日

        Scanner sc = new Scanner(System.in);
        //输入出生年月日
        String str1 = sc.nextLine();
        LocalDate ld1 = LocalDate.parse(str1);//默认格式为yyyy-MM-dd

        //也可以使用DateTimeFormatter设置要输入的格式类型
        String str2 = sc.nextLine();
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd");
        LocalDate ld2 = LocalDate.parse(str2,dtf);

        //写死，直接设置我的生日
        LocalDate birth = LocalDate.of(2000,5,6);
//        LocalDate birth2 = birth.withYear(2001);
        LocalDate now = LocalDate.now();
//        System.out.println(birth);
        System.out.println(ChronoUnit.DAYS.between(birth, now));
    }
}
