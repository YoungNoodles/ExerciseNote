package com.cetc.ComplexTest;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Calendar;
import java.util.Date;
import java.util.Scanner;

public class Test005 {
    public static void main(String[] args) throws ParseException {
        //判断某一年是平年还是闰年
        //按一年的日子计算
        //JDK8做法
        Scanner sc = new Scanner(System.in);
        //输入要判断的年份
        int year = sc.nextInt();
        //创建目标年和下一年的LocalDate对象
        //用不到时分秒，所以不需要创建LocalDateTime的对象
        LocalDate target = LocalDate.of(year++, 1, 1);
        LocalDate nextYear = LocalDate.of(year--, 1, 1);
        //判断目标年的天数。366就是闰年，365就是平年，输出结果
        if (ChronoUnit.DAYS.between(target, nextYear) == 366) {
            System.out.println(year + "年是闰年");
        } else {
            System.out.println(year + "年是平年");
        }
        System.out.println("----------------------------------------------");

        //JDK7做法
        //写年份，解析成Date对象
        //接收上面一段键盘录入的回车符号
        String str = sc.nextLine();
        String str1 = sc.nextLine();
        //将输入的年份解析成Date对象
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy");
        Date d1 = sdf.parse(str1);
//        System.out.println(d1);
        //创建目标年的日历对象
        Calendar cal1 = Calendar.getInstance();
        cal1.setTime(d1);
        //创建下一年的日历对象
        Calendar cal2 = Calendar.getInstance();
        cal2.setTime(d1);
        cal2.add(Calendar.YEAR, 1);
//        System.out.println((cal2.getTimeInMillis() - cal1.getTimeInMillis()) / 1000 / 60 / 60 / 24);
        //判断天数是否是366天，是则是闰年，不是就是平年
        if ((cal2.getTimeInMillis() - cal1.getTimeInMillis()) / 1000 / 60 / 60 / 24 == 366) {
            System.out.println(str1 + "年是闰年");
        } else {
            System.out.println(str1 + "年是平年");
        }
    }
}
