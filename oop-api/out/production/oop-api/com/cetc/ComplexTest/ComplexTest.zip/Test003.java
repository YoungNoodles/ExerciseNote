package com.cetc.ComplexTest;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Test003 {
    //重写toBinaryString方法，将十进制数字转换成二进制字符串
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("输入要转换的十进制数");
        int num = 0;
        while (true) {
            //定义一个字符串来接收输入的十进制数
            String str = sc.nextLine();
            //判断是否符合条件，非0开头，不含字母字符
            if (str.charAt(0) == 48) {
                System.out.println("不能以0开头");
            } else if (ifMatch(str)) {
                System.out.println("不能含字母");
            } else {
                for (int i = 0; i < str.length(); i++) {
                    num = num * 10 + (str.charAt(i) - 48);
                }
                break;
            }

        }
//        System.out.println(num);
        System.out.println(Integer.toBinaryString(num));
        System.out.println(toBinaryString(num));
    }

    public static boolean ifMatch(String str) {
        String regex = "[^\\d]";
        //正则对象
        Pattern p = Pattern.compile(regex);
        //爬取对象
        Matcher m = p.matcher(str);

        return m.find();
    }

    public static String toBinaryString(int num) {
        //定义一个容器接收二进制反序
        StringBuilder result = new StringBuilder();
        while (num >= 2) {
//                result.append(num % 2);
                result.insert(0,num % 2);
                num /= 2;
        }
//        result.append(1);
        result.insert(0,1);

//        System.out.println(result);
//        return result.reverse().toString();
        return result.toString();
    }
}
