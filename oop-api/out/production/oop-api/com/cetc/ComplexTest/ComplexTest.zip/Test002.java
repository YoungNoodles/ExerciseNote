package com.cetc.ComplexTest;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Test002 {
    public static void main(String[] args) {
        //实现parseInt()方法，将字符串转换成int类型
        Scanner sc = new Scanner(System.in);
        //定义整型变量接收转化后的结果
        int num = 0;
        num = getNum(sc, num);
        //打印最终结果
        System.out.println(num);
    }

    private static int getNum(Scanner sc, int num) {
        //编写正则表达式用于判断是否有除去数字之外的内容
        String regex = "[^\\d]";
        while (true) {
            System.out.println("请输入要转换的数字");
            //定义字符串对象接收字符串
            String str = sc.nextLine();
            //定义Pattern对象接收字符串
            Pattern p = Pattern.compile(regex);
            Matcher m = p.matcher(str);
            if (str.charAt(0) == 48) {
                System.out.println("首个数字不能为0，请重新输入！");
            } else if (m.find()) {
                System.out.println("输入非法，请重新输入！");
            } else {
                for (int i = 0; i < str.length(); i++) {
                    num = num * 10 + (str.charAt(i) - 48);
                }
                break;
            }
        }
        return num;
    }
}
