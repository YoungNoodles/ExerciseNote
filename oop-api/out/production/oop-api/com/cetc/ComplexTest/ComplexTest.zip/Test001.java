package com.cetc.ComplexTest;

import java.util.ArrayList;
import java.util.Scanner;

public class Test001 {
    public static void main(String[] args) {
        //键盘录入1-100之间的数，加入到集合，直到总和大于等于200
        //定义一个Integer对象的集合存储数字
        ArrayList<Integer> num = new ArrayList<>();

        Scanner sc = new Scanner(System.in);

        while (isUp(num)) {
            //判断数字是否在范围内
            int inPut = Integer.parseInt(sc.nextLine());
            if (inPut < 1 || inPut > 100) {
                System.out.println("输入非法！请重新输入：");
            } else {
                //给集合添加新输入的数字
                num.add(inPut);
            }
        }

        System.out.println(num);
    }

    private static boolean isUp(ArrayList<Integer> num) {
        //定义计数器count，计算总和
        int count = 0;
        //给计数器计算新的总和
        for (Integer value : num) {
            count += value;
        }
        //判断是否超过200，超过就跳出，不超过就继续输入
        if (count >= 200) {
            System.out.println(count);
            return false;
        } else if (count > 0) {
            System.out.println("请继续输入：");
        }
        return true;
    }
}
