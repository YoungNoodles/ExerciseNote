package com.CETC.a02polymorphismDemo2;

public class Pet {
    private String age;
    private String color;

    public Pet() {
    }

    public Pet(String age, String color) {
        this.age = age;
        this.color = color;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getType() {
        return "宠物";
    }

    public void eat(String something) {
        System.out.println("不管输出啥先吃着" + something);
    }
}
