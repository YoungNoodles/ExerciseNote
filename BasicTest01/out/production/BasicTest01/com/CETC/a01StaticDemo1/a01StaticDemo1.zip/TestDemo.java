package com.CETC.a01StaticDemo1;

import java.util.ArrayList;

public class TestDemo {
    public static void main(String[] args) {
        int[] arr = {1,2,3,4,5,6,7,8,9};
        double[] brr = {1.2,3.3};
        System.out.println(ArrayUtil.printArr(arr));
        System.out.println(ArrayUtil.getAverage(brr));

        Student s1 = new Student("zhangsan",10,"男");
        Student s2 = new Student("lisi",12,"男");
        Student s3 = new Student("wangwu",14,"女");

        ArrayList<Student> students = new ArrayList<>();
        students.add(s1);
        students.add(s2);
        students.add(s3);

        System.out.println(StudentUtil.getMaxAge(students));
    }
}
