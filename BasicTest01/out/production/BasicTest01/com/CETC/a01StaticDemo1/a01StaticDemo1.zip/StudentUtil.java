package com.CETC.a01StaticDemo1;

import java.util.ArrayList;

public class StudentUtil {
    private StudentUtil() {
    }

    public static int getMaxAge(ArrayList<Student> student) {
        if (student.size() > 0) {
            int temp = student.get(0).getAge();
            for (int i = 1; i < student.size(); i++) {
                temp = Math.max(temp, student.get(i).getAge());
            }
            return temp;
        }
        return -1;
    }
}
