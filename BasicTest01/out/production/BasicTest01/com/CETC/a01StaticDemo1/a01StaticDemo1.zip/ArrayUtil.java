package com.CETC.a01StaticDemo1;

import java.util.StringJoiner;

public class ArrayUtil {
    private ArrayUtil() {
    }

    public static String printArr(int[] arr) {
        StringJoiner sj = new StringJoiner("， ", "[", "]");
        for (int value : arr) {
            sj.add(value + "");
        }
        return sj.toString();
    }

    public static double getAverage(double[] arr) {
        double sum = 0;
        for (double value : arr) {
            sum += value;
        }
        return sum / arr.length;
    }
}
